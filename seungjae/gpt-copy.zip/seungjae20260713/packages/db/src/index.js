// @workspace/db — stub placeholder
