import type { Timeframe } from '@/lib/api';

export const CHART_TIMEFRAMES = [
  { key: '1m', label: '1분' },
  { key: '3m', label: '3분' },
  { key: '5m', label: '5분' },
  { key: '15m', label: '15분' },
  { key: '30m', label: '30분' },
  { key: '1H', label: '1시간' },
  { key: '4H', label: '4시간' },
  { key: '8H', label: '8시간' },
  { key: '12H', label: '12시간' },
  { key: '1D', label: '1일' },
  { key: '3D', label: '3일' },
  { key: '5D', label: '5일' },
  { key: '15D', label: '15일' },
  { key: '1M', label: '1달' },
  { key: '3M', label: '3달' },
  { key: '6M', label: '6달' },
  { key: '1Y', label: '1년' },
] as const satisfies ReadonlyArray<{ key: Timeframe; label: string }>;

export type VisibleChartTimeframe = (typeof CHART_TIMEFRAMES)[number]['key'];

export const CHART_FRAMES_STORAGE_KEY = 'sa-chart-frames-v1';
export const CHART_FRAMES_CHANGE_EVENT = 'sa-chart-frames-changed';

const DEFAULT_VISIBLE: VisibleChartTimeframe[] = [
  '1m',
  '5m',
  '15m',
  '1H',
  '4H',
  '1D',
  '1M',
  '1Y',
];

export function loadVisibleChartTimeframes(): VisibleChartTimeframe[] {
  if (typeof window === 'undefined') return DEFAULT_VISIBLE;
  try {
    const parsed = JSON.parse(window.localStorage.getItem(CHART_FRAMES_STORAGE_KEY) ?? '[]') as unknown;
    if (!Array.isArray(parsed)) return DEFAULT_VISIBLE;
    const visible = CHART_TIMEFRAMES
      .filter((item) => parsed.includes(item.key))
      .map((item) => item.key);
    return visible.length ? visible : DEFAULT_VISIBLE;
  } catch {
    return DEFAULT_VISIBLE;
  }
}

export function saveVisibleChartTimeframes(frames: VisibleChartTimeframe[]) {
  if (typeof window === 'undefined') return;
  const ordered = CHART_TIMEFRAMES
    .filter((item) => frames.includes(item.key))
    .map((item) => item.key);
  const safe = ordered.length ? ordered : [CHART_TIMEFRAMES[0].key];
  window.localStorage.setItem(CHART_FRAMES_STORAGE_KEY, JSON.stringify(safe));
  window.dispatchEvent(new CustomEvent(CHART_FRAMES_CHANGE_EVENT, { detail: safe }));
}
