import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  Bell,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  CirclePause,
  CirclePlay,
  Eye,
  EyeOff,
  FileText,
  Info,
  KeyRound,
  Loader2,
  RefreshCw,
  Search,
  SlidersHorizontal,
  Star,
  Settings2,
  ShieldAlert,
  Zap,
  X,
} from "lucide-react";
import {
  ColorType,
  CrosshairMode,
  LineStyle,
  createChart,
  type IChartApi,
  type Time,
  type UTCTimestamp,
} from "lightweight-charts";
import { authorizedFetch } from "@/lib/auth-fetch";
import { apiGet } from "@/lib/api";
import { BottomNav } from "@/components/bottom-nav";
import { useAssetMode } from "@/lib/asset-mode";
import { cn } from "@/lib/utils";

export type CryptoWorkspaceViewMode = "condition" | "chart" | "auto";

type Props = {
  viewMode: CryptoWorkspaceViewMode;
  onViewModeChange: (mode: CryptoWorkspaceViewMode) => void;
  onBackToStock: () => void;
  onBackToSpot: () => void;
};

type AnyObj = Record<string, any>;
type Direction = "LONG" | "SHORT" | "WAIT";
type PositionMode = "one_way_mode" | "hedge_mode";
type MarginMode = "isolated" | "crossed";
type ExecutionMode = "PAPER" | "REAL";
type Timeframe =
  | "1m"
  | "3m"
  | "5m"
  | "15m"
  | "30m"
  | "1H"
  | "4H"
  | "6H"
  | "8H"
  | "12H"
  | "1D"
  | "3D"
  | "5D"
  | "10D"
  | "15D"
  | "30D"
  | "1W"
  | "1M"
  | "1Y";
type OverlayKey =
  | "ma5"
  | "ma20"
  | "ma60"
  | "bollinger"
  | "vwap"
  | "volume"
  | "levels"
  | "arrows";
type ScannerCategory = "tradingValue" | "volume" | "gainers" | "losers";
type ScannerDirection = "LONG" | "SHORT";
type IndicatorProfileKey = "minute" | "hour" | "day" | "long";
type IndicatorProfiles = Record<
  IndicatorProfileKey,
  Record<OverlayKey, boolean>
>;

type SortKey =
  | "symbol"
  | "tradingValue"
  | "volume"
  | "change"
  | "aiLong"
  | "aiShort";
type SortDirection = "none" | "asc" | "desc";
type ScoreModalKind = "LONG" | "SHORT" | "TOTAL" | null;
type SectionKey =
  | "search"
  | "scores"
  | "ai"
  | "auto"
  | "positions"
  | "journal"
  | "status";
type OpenSections = Record<SectionKey, boolean>;
type AssetAlertRule = {
  symbol: string;
  targetEnabled: boolean;
  targetDirection: "above" | "below";
  targetPrice: string;
  changeEnabled: boolean;
  changeDirection: "up" | "down";
  changePercent: string;
  newsEnabled: boolean;
  lastTriggeredKey?: string;
};

type Candle = {
  time: UTCTimestamp;
  sourceTime: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
};

type Ticker = {
  symbol: string;
  price: number;
  markPrice: number;
  indexPrice: number;
  changePercent24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  tradingValue24h: number;
  fundingRate: number;
  openInterest: number;
  bidPrice: number;
  askPrice: number;
};

type PatternSignal = {
  key: string;
  label: string;
  direction: "LONG" | "SHORT" | "NEUTRAL";
  weight: number;
};

type Analysis = {
  symbol: string;
  currentPrice: number;
  previousClose: number;
  changePercent: number;
  sma5: number | null;
  sma20: number | null;
  sma60: number | null;
  rsi: number | null;
  macd: number | null;
  macdSignal: number | null;
  atr: number;
  atrPercent: number;
  volumeRatio: number;
  vwap: number | null;
  support1: number;
  support2: number;
  resistance1: number;
  resistance2: number;
  longScore: number;
  shortScore: number;
  direction: Direction;
  confidence: "높음" | "보통" | "낮음";
  longReasons: string[];
  shortReasons: string[];
  patterns: PatternSignal[];
  targetLong: number;
  stopLong: number;
  targetShort: number;
  stopShort: number;
  marketBias: number;
  generatedAt: string;
};

type ScannerRow = {
  ticker: Ticker;
  analysis: Analysis;
  rank: number;
};

type Position = {
  symbol: string;
  holdSide: string;
  total: number;
  available: number;
  openPriceAvg: number;
  markPrice: number;
  unrealizedPL: number;
  liquidationPrice: number;
  leverage: number;
  marginMode: string;
  marginSize: number;
  breakEvenPrice: number;
};

type AutoSettings = {
  monitorEnabled: boolean;
  executionMode: ExecutionMode;
  positionMode: PositionMode;
  marginMode: MarginMode;
  leverage: number;
  marginAmountUSDT: number;
  minScore: number;
  stopLossPercent: number;
  targetProfitPercent: number;
  maxOpenPositions: number;
  maxDailyOrders: number;
};

type PlanResponse = {
  ok: boolean;
  approvalRequired: boolean;
  approvalToken: string;
  approvalExpiresAt: string;
  plan: AnyObj;
  warning?: string;
};

type WatchPlan = {
  kind: "WATCH";
  symbol: string;
  timeframe: Timeframe;
  direction: "WAIT";
  longScore: number;
  shortScore: number;
  minimumScore: number;
  supportTrigger: number;
  resistanceTrigger: number;
  marginAmountUSDT: number;
  leverage: number;
  stopLossPercent: number;
  targetProfitPercent: number;
  availableUSDT: number | null;
  accountEquityUSDT: number | null;
  reasons: string[];
  createdAt: string;
};

type FeedLine = {
  id: string;
  at: Date;
  tone: "LONG" | "SHORT" | "WAIT" | "INFO";
  text: string;
};

const TIMEFRAMES: Array<{
  key: Timeframe;
  label: string;
  group: IndicatorProfileKey;
}> = [
  { key: "1m", label: "1분", group: "minute" },
  { key: "3m", label: "3분", group: "minute" },
  { key: "5m", label: "5분", group: "minute" },
  { key: "15m", label: "15분", group: "minute" },
  { key: "30m", label: "30분", group: "minute" },
  { key: "1H", label: "1시간", group: "hour" },
  { key: "4H", label: "4시간", group: "hour" },
  { key: "6H", label: "6시간", group: "hour" },
  { key: "8H", label: "8시간", group: "hour" },
  { key: "12H", label: "12시간", group: "hour" },
  { key: "1D", label: "일봉", group: "day" },
  { key: "3D", label: "3일", group: "day" },
  { key: "5D", label: "5일", group: "day" },
  { key: "10D", label: "10일", group: "day" },
  { key: "15D", label: "15일", group: "day" },
  { key: "30D", label: "30일", group: "day" },
  { key: "1W", label: "주봉", group: "long" },
  { key: "1M", label: "월봉", group: "long" },
  { key: "1Y", label: "년봉", group: "long" },
];

const TIMEFRAME_GROUPS: Array<{ key: IndicatorProfileKey; label: string }> = [
  { key: "minute", label: "분봉" },
  { key: "hour", label: "시간봉" },
  { key: "day", label: "일봉" },
  { key: "long", label: "장기봉" },
];

const OVERLAYS: Array<{ key: OverlayKey; label: string }> = [
  { key: "ma5", label: "MA5" },
  { key: "ma20", label: "MA20" },
  { key: "ma60", label: "MA60" },
  { key: "bollinger", label: "볼린저" },
  { key: "vwap", label: "VWAP" },
  { key: "volume", label: "거래량" },
  { key: "levels", label: "지지·저항" },
  { key: "arrows", label: "롱·숏 화살표" },
];

const SCANNER_CATEGORIES: Array<{ key: ScannerCategory; label: string }> = [
  { key: "tradingValue", label: "거래대금" },
  { key: "volume", label: "거래량" },
  { key: "gainers", label: "급상승" },
  { key: "losers", label: "급하락" },
];

const INDICATOR_PROFILE_TABS: Array<{
  key: IndicatorProfileKey;
  label: string;
}> = [
  { key: "minute", label: "분봉" },
  { key: "hour", label: "시간봉" },
  { key: "day", label: "일봉" },
  { key: "long", label: "주·월·년봉" },
];

const DEFAULT_INDICATOR_PROFILES: IndicatorProfiles = {
  minute: {
    ma5: true,
    ma20: true,
    ma60: false,
    bollinger: false,
    vwap: true,
    volume: true,
    levels: true,
    arrows: true,
  },
  hour: {
    ma5: true,
    ma20: true,
    ma60: true,
    bollinger: true,
    vwap: true,
    volume: true,
    levels: true,
    arrows: true,
  },
  day: {
    ma5: false,
    ma20: true,
    ma60: true,
    bollinger: true,
    vwap: false,
    volume: true,
    levels: true,
    arrows: true,
  },
  long: {
    ma5: false,
    ma20: true,
    ma60: true,
    bollinger: false,
    vwap: false,
    volume: true,
    levels: true,
    arrows: true,
  },
};

const DEFAULT_SETTINGS: AutoSettings = {
  monitorEnabled: true,
  executionMode: "PAPER",
  positionMode: "one_way_mode",
  marginMode: "isolated",
  leverage: Number.NaN,
  marginAmountUSDT: Number.NaN,
  minScore: Number.NaN,
  stopLossPercent: Number.NaN,
  targetProfitPercent: Number.NaN,
  maxOpenPositions: Number.NaN,
  maxDailyOrders: Number.NaN,
};

const SETTINGS_KEY = "crypto-long-short-settings.v1";
const SYMBOL_KEY = "crypto-long-short-symbol.v1";
const INDICATOR_SETTINGS_KEY = "crypto-long-short-indicators.v2";
const EXECUTION_KEY_SESSION_KEY = "crypto-auto-execution-key.session.v1";
const VISIBLE_TIMEFRAMES_KEY = "crypto-visible-timeframes.v1";
const OPEN_SECTIONS_KEY = "crypto-collapsible-sections.v1";
const FAVORITES_KEY = "asset-favorites.v1";
const ALERTS_KEY = "asset-alert-rules.v1";

const DEFAULT_OPEN_SECTIONS: OpenSections = {
  search: true,
  scores: true,
  ai: true,
  auto: false,
  positions: false,
  journal: false,
  status: false,
};

function loadJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function saveJson<T>(key: string, value: T) {
  if (typeof window !== "undefined")
    window.localStorage.setItem(key, JSON.stringify(value));
  return value;
}

function timeframeLabel(value: Timeframe) {
  return TIMEFRAMES.find((item) => item.key === value)?.label ?? value;
}

function numberOf(value: unknown, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function average(values: number[]) {
  if (!values.length) return null;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function sma(values: number[], period: number) {
  if (values.length < period) return null;
  return average(values.slice(-period));
}

function emaSeries(values: number[], period: number) {
  if (!values.length) return [] as number[];
  const multiplier = 2 / (period + 1);
  const result: number[] = [];
  let current = values[0];
  for (let index = 0; index < values.length; index += 1) {
    current =
      index === 0
        ? values[index]
        : (values[index] - current) * multiplier + current;
    result.push(current);
  }
  return result;
}

function rsi(values: number[], period = 14) {
  if (values.length <= period) return null;
  let gains = 0;
  let losses = 0;
  for (let index = values.length - period; index < values.length; index += 1) {
    const difference = values[index] - values[index - 1];
    if (difference >= 0) gains += difference;
    else losses += Math.abs(difference);
  }
  if (losses === 0) return 100;
  const relativeStrength = gains / period / (losses / period);
  return 100 - 100 / (1 + relativeStrength);
}

function macdSnapshot(values: number[]) {
  if (values.length < 35) return { macd: null, signal: null };
  const fast = emaSeries(values, 12);
  const slow = emaSeries(values, 26);
  const macdRows = values.map(
    (_, index) => (fast[index] ?? 0) - (slow[index] ?? 0),
  );
  const signalRows = emaSeries(macdRows, 9);
  return {
    macd: macdRows.at(-1) ?? null,
    signal: signalRows.at(-1) ?? null,
  };
}

function atr(candles: Candle[], period = 14) {
  if (candles.length < 2) return 0;
  const rows = candles.slice(-Math.min(period + 1, candles.length));
  const ranges: number[] = [];
  for (let index = 1; index < rows.length; index += 1) {
    const current = rows[index];
    const previous = rows[index - 1];
    ranges.push(
      Math.max(
        current.high - current.low,
        Math.abs(current.high - previous.close),
        Math.abs(current.low - previous.close),
      ),
    );
  }
  return average(ranges) ?? 0;
}

function standardDeviation(values: number[]) {
  const mean = average(values);
  if (mean == null || !values.length) return null;
  return Math.sqrt(
    values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length,
  );
}

function rollingSma(candles: Candle[], period: number) {
  const rows: Array<{ time: Time; value: number }> = [];
  for (let index = period - 1; index < candles.length; index += 1) {
    const values = candles
      .slice(index - period + 1, index + 1)
      .map((row) => row.close);
    const value = average(values);
    if (value != null) rows.push({ time: candles[index].time, value });
  }
  return rows;
}

function rollingBollinger(candles: Candle[], period = 20) {
  const upper: Array<{ time: Time; value: number }> = [];
  const middle: Array<{ time: Time; value: number }> = [];
  const lower: Array<{ time: Time; value: number }> = [];
  for (let index = period - 1; index < candles.length; index += 1) {
    const values = candles
      .slice(index - period + 1, index + 1)
      .map((row) => row.close);
    const mean = average(values);
    const deviation = standardDeviation(values);
    if (mean == null || deviation == null) continue;
    const time = candles[index].time;
    upper.push({ time, value: mean + deviation * 2 });
    middle.push({ time, value: mean });
    lower.push({ time, value: mean - deviation * 2 });
  }
  return { upper, middle, lower };
}

function rollingVwap(candles: Candle[]) {
  let cumulativePriceVolume = 0;
  let cumulativeVolume = 0;
  return candles.map((row) => {
    const typical = (row.high + row.low + row.close) / 3;
    cumulativePriceVolume += typical * row.volume;
    cumulativeVolume += row.volume;
    return {
      time: row.time as Time,
      value:
        cumulativeVolume > 0
          ? cumulativePriceVolume / cumulativeVolume
          : row.close,
    };
  });
}

function normalizeCandles(rows: AnyObj[]) {
  return rows
    .map((row, index) => {
      const open = numberOf(row.open, Number.NaN);
      const high = numberOf(row.high, Number.NaN);
      const low = numberOf(row.low, Number.NaN);
      const close = numberOf(row.close, Number.NaN);
      if (![open, high, low, close].every(Number.isFinite)) return null;
      const rawTime = row.time;
      const milliseconds = numberOf(rawTime, Number.NaN);
      const parsed =
        Number.isFinite(milliseconds) && milliseconds > 1_000_000_000
          ? milliseconds
          : Date.parse(String(rawTime ?? ""));
      const fallback = Date.now() - (rows.length - index) * 60_000;
      const unix = Math.floor(
        (Number.isFinite(parsed) ? parsed : fallback) / 1000,
      ) as UTCTimestamp;
      return {
        time: unix,
        sourceTime: String(rawTime ?? ""),
        open,
        high: Math.max(high, open, close),
        low: Math.min(low, open, close),
        close,
        volume: Math.max(0, numberOf(row.volume, 0)),
        quoteVolume: Math.max(0, numberOf(row.quoteVolume, 0)),
      } satisfies Candle;
    })
    .filter((row): row is Candle => row != null)
    .sort((a, b) => Number(a.time) - Number(b.time))
    .filter(
      (row, index, source) =>
        index === 0 || row.time !== source[index - 1].time,
    );
}

function detectPatterns(
  candles: Candle[],
  support: number,
  resistance: number,
) {
  const patterns: PatternSignal[] = [];
  if (candles.length < 8) return patterns;
  const last = candles.at(-1)!;
  const previous = candles.at(-2)!;
  const recent = candles.slice(-20, -1);
  const recentHigh = Math.max(...recent.map((row) => row.high));
  const recentLow = Math.min(...recent.map((row) => row.low));
  const body = Math.abs(last.close - last.open);
  const range = Math.max(last.high - last.low, Number.EPSILON);
  const lowerWick = Math.min(last.open, last.close) - last.low;
  const upperWick = last.high - Math.max(last.open, last.close);

  if (
    last.close > recentHigh &&
    last.volume > (average(recent.map((row) => row.volume)) ?? 0) * 1.3
  ) {
    patterns.push({
      key: "breakout",
      label: "거래량 동반 상단 돌파",
      direction: "LONG",
      weight: 14,
    });
  }
  if (
    last.close < recentLow &&
    last.volume > (average(recent.map((row) => row.volume)) ?? 0) * 1.3
  ) {
    patterns.push({
      key: "breakdown",
      label: "거래량 동반 하단 이탈",
      direction: "SHORT",
      weight: 14,
    });
  }
  if (
    previous.close < previous.open &&
    last.close > last.open &&
    last.open <= previous.close &&
    last.close >= previous.open
  ) {
    patterns.push({
      key: "bullish-engulf",
      label: "상승 장악형",
      direction: "LONG",
      weight: 8,
    });
  }
  if (
    previous.close > previous.open &&
    last.close < last.open &&
    last.open >= previous.close &&
    last.close <= previous.open
  ) {
    patterns.push({
      key: "bearish-engulf",
      label: "하락 장악형",
      direction: "SHORT",
      weight: 8,
    });
  }
  if (
    lowerWick > body * 2 &&
    lowerWick > upperWick * 1.5 &&
    last.close > last.open
  ) {
    patterns.push({
      key: "hammer",
      label: "망치형 반등",
      direction: "LONG",
      weight: 7,
    });
  }
  if (
    upperWick > body * 2 &&
    upperWick > lowerWick * 1.5 &&
    last.close < last.open
  ) {
    patterns.push({
      key: "shooting-star",
      label: "유성형 반락",
      direction: "SHORT",
      weight: 7,
    });
  }
  if (body / range < 0.12) {
    patterns.push({
      key: "doji",
      label: "도지·방향 대기",
      direction: "NEUTRAL",
      weight: 0,
    });
  }

  const closes = candles.slice(-35).map((row) => row.close);
  const localLows = closes
    .map((value, index) => ({ value, index }))
    .filter(
      (row) =>
        row.index > 0 &&
        row.index < closes.length - 1 &&
        row.value <= closes[row.index - 1] &&
        row.value <= closes[row.index + 1],
    );
  const localHighs = closes
    .map((value, index) => ({ value, index }))
    .filter(
      (row) =>
        row.index > 0 &&
        row.index < closes.length - 1 &&
        row.value >= closes[row.index - 1] &&
        row.value >= closes[row.index + 1],
    );
  if (localLows.length >= 2) {
    const [left, right] = localLows.slice(-2);
    if (
      right.index - left.index >= 4 &&
      Math.abs(right.value - left.value) / Math.max(left.value, 1) < 0.012 &&
      last.close > support
    ) {
      patterns.push({
        key: "double-bottom",
        label: "쌍바닥 후보",
        direction: "LONG",
        weight: 9,
      });
    }
  }
  if (localHighs.length >= 2) {
    const [left, right] = localHighs.slice(-2);
    if (
      right.index - left.index >= 4 &&
      Math.abs(right.value - left.value) / Math.max(left.value, 1) < 0.012 &&
      last.close < resistance
    ) {
      patterns.push({
        key: "double-top",
        label: "쌍봉 후보",
        direction: "SHORT",
        weight: 9,
      });
    }
  }
  return patterns.slice(0, 6);
}

function analyze(
  symbol: string,
  candles: Candle[],
  ticker: Ticker | null,
  marketBias: number,
  minScore: number,
): Analysis | null {
  if (candles.length < 25) return null;
  const closes = candles.map((row) => row.close);
  const last = candles.at(-1)!;
  const previous = candles.at(-2)!;
  const currentPrice = ticker?.markPrice || last.close;
  const previousClose = previous.close;
  const changePercent = previousClose
    ? ((currentPrice - previousClose) / previousClose) * 100
    : 0;
  const sma5 = sma(closes, 5);
  const sma20 = sma(closes, 20);
  const sma60 = sma(closes, 60);
  const currentRsi = rsi(closes);
  const macd = macdSnapshot(closes);
  const currentAtr = atr(candles);
  const atrPercent = currentPrice ? (currentAtr / currentPrice) * 100 : 0;
  const recentVolumes = candles
    .slice(-21, -1)
    .map((row) => row.volume)
    .filter((value) => value > 0);
  const averageVolume = average(recentVolumes) ?? 0;
  const volumeRatio = averageVolume > 0 ? last.volume / averageVolume : 1;
  const vwapRows = rollingVwap(candles);
  const currentVwap = vwapRows.at(-1)?.value ?? null;
  const levelRows = candles.slice(-50, -1);
  const support1 = Math.min(...levelRows.slice(-20).map((row) => row.low));
  const support2 = Math.min(...levelRows.map((row) => row.low));
  const resistance1 = Math.max(...levelRows.slice(-20).map((row) => row.high));
  const resistance2 = Math.max(...levelRows.map((row) => row.high));
  const patterns = detectPatterns(candles, support1, resistance1);

  let longScore = 35;
  let shortScore = 35;
  const longReasons: string[] = [];
  const shortReasons: string[] = [];

  if (sma5 != null && sma20 != null) {
    if (sma5 > sma20) {
      longScore += 10;
      shortScore -= 4;
      longReasons.push("MA5가 MA20 위");
    } else {
      shortScore += 10;
      longScore -= 4;
      shortReasons.push("MA5가 MA20 아래");
    }
  }
  if (sma20 != null && sma60 != null) {
    if (sma20 > sma60) {
      longScore += 8;
      longReasons.push("중기 상승 배열");
    } else {
      shortScore += 8;
      shortReasons.push("중기 하락 배열");
    }
  }
  if (currentVwap != null) {
    if (currentPrice > currentVwap) {
      longScore += 6;
      longReasons.push("VWAP 상단 유지");
    } else {
      shortScore += 6;
      shortReasons.push("VWAP 하단 체류");
    }
  }
  if (currentRsi != null) {
    if (currentRsi >= 55 && currentRsi <= 72) {
      longScore += 8;
      longReasons.push(`RSI ${currentRsi.toFixed(0)} 상승 모멘텀`);
    }
    if (currentRsi <= 45 && currentRsi >= 28) {
      shortScore += 8;
      shortReasons.push(`RSI ${currentRsi.toFixed(0)} 하락 모멘텀`);
    }
    if (currentRsi > 76) {
      shortScore += 9;
      longScore -= 5;
      shortReasons.push("RSI 과매수 주의");
    }
    if (currentRsi < 24) {
      longScore += 9;
      shortScore -= 5;
      longReasons.push("RSI 과매도 반등 후보");
    }
  }
  if (macd.macd != null && macd.signal != null) {
    if (macd.macd > macd.signal) {
      longScore += 9;
      longReasons.push("MACD 상향 우세");
    } else {
      shortScore += 9;
      shortReasons.push("MACD 하향 우세");
    }
  }
  if (volumeRatio >= 1.5) {
    if (last.close >= last.open) {
      longScore += 8;
      longReasons.push(`거래량 ${volumeRatio.toFixed(1)}배 양봉`);
    } else {
      shortScore += 8;
      shortReasons.push(`거래량 ${volumeRatio.toFixed(1)}배 음봉`);
    }
  }
  if (currentPrice > resistance1) {
    longScore += 10;
    longReasons.push("단기 저항 돌파");
  }
  if (currentPrice < support1) {
    shortScore += 10;
    shortReasons.push("단기 지지 이탈");
  }
  for (const pattern of patterns) {
    if (pattern.direction === "LONG") {
      longScore += pattern.weight;
      longReasons.push(pattern.label);
    } else if (pattern.direction === "SHORT") {
      shortScore += pattern.weight;
      shortReasons.push(pattern.label);
    }
  }

  if (marketBias > 0) {
    longScore += Math.min(8, marketBias);
    if (marketBias >= 4) longReasons.push("비트코인·시장 방향 상승");
  } else if (marketBias < 0) {
    shortScore += Math.min(8, Math.abs(marketBias));
    if (marketBias <= -4) shortReasons.push("비트코인·시장 방향 하락");
  }

  const fundingRate = ticker?.fundingRate ?? 0;
  if (fundingRate > 0.0006) {
    shortScore += 4;
    shortReasons.push("양(+) 펀딩 과열");
  } else if (fundingRate < -0.0006) {
    longScore += 4;
    longReasons.push("음(-) 펀딩 과열");
  }

  if (atrPercent > 4) {
    longScore -= 5;
    shortScore -= 5;
  }

  longScore = Math.round(clamp(longScore, 0, 100));
  shortScore = Math.round(clamp(shortScore, 0, 100));
  const difference = longScore - shortScore;
  const direction: Direction =
    longScore >= minScore && difference >= 10
      ? "LONG"
      : shortScore >= minScore && difference <= -10
        ? "SHORT"
        : "WAIT";
  const strongest = Math.max(longScore, shortScore);
  const confidence =
    strongest >= 85 && Math.abs(difference) >= 20
      ? "높음"
      : strongest >= 70 && Math.abs(difference) >= 10
        ? "보통"
        : "낮음";
  const riskDistance = Math.max(currentAtr * 1.5, currentPrice * 0.008);
  const rewardDistance = riskDistance * 2;

  return {
    symbol,
    currentPrice,
    previousClose,
    changePercent,
    sma5,
    sma20,
    sma60,
    rsi: currentRsi,
    macd: macd.macd,
    macdSignal: macd.signal,
    atr: currentAtr,
    atrPercent,
    volumeRatio,
    vwap: currentVwap,
    support1,
    support2,
    resistance1,
    resistance2,
    longScore,
    shortScore,
    direction,
    confidence,
    longReasons: [...new Set(longReasons)].slice(0, 6),
    shortReasons: [...new Set(shortReasons)].slice(0, 6),
    patterns,
    targetLong: currentPrice + rewardDistance,
    stopLong: currentPrice - riskDistance,
    targetShort: currentPrice - rewardDistance,
    stopShort: currentPrice + riskDistance,
    marketBias,
    generatedAt: new Date().toISOString(),
  };
}

function loadSettings() {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const parsed = JSON.parse(
      window.localStorage.getItem(SETTINGS_KEY) ?? "{}",
    ) as Partial<AutoSettings>;
    const numeric = (value: unknown) =>
      Number.isFinite(Number(value)) && value !== null && value !== ""
        ? Number(value)
        : Number.NaN;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      leverage: numeric(parsed.leverage),
      marginAmountUSDT: numeric(parsed.marginAmountUSDT),
      minScore: numeric(parsed.minScore),
      stopLossPercent: numeric(parsed.stopLossPercent),
      targetProfitPercent: numeric(parsed.targetProfitPercent),
      maxOpenPositions: numeric(parsed.maxOpenPositions),
      maxDailyOrders: numeric(parsed.maxDailyOrders),
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function saveSettings(settings: AutoSettings) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }
  return settings;
}

function indicatorProfileForTimeframe(
  timeframe: Timeframe,
): IndicatorProfileKey {
  return TIMEFRAMES.find((item) => item.key === timeframe)?.group ?? "minute";
}

function loadIndicatorProfiles(): IndicatorProfiles {
  if (typeof window === "undefined") return DEFAULT_INDICATOR_PROFILES;
  try {
    const parsed = JSON.parse(
      window.localStorage.getItem(INDICATOR_SETTINGS_KEY) ?? "{}",
    ) as Partial<IndicatorProfiles>;
    return {
      minute: {
        ...DEFAULT_INDICATOR_PROFILES.minute,
        ...(parsed.minute ?? {}),
      },
      hour: { ...DEFAULT_INDICATOR_PROFILES.hour, ...(parsed.hour ?? {}) },
      day: { ...DEFAULT_INDICATOR_PROFILES.day, ...(parsed.day ?? {}) },
      long: { ...DEFAULT_INDICATOR_PROFILES.long, ...(parsed.long ?? {}) },
    };
  } catch {
    return DEFAULT_INDICATOR_PROFILES;
  }
}

function saveIndicatorProfiles(profiles: IndicatorProfiles) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(
      INDICATOR_SETTINGS_KEY,
      JSON.stringify(profiles),
    );
  }
  return profiles;
}

async function getProtected<T>(url: string): Promise<T> {
  const response = await authorizedFetch(url, { cache: "no-store" });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      payload.message ?? payload.error ?? `HTTP_${response.status}`,
    );
  return payload as T;
}

async function postProtected<T>(
  url: string,
  body: AnyObj,
  executionKey: string,
): Promise<T> {
  const normalizedKey = normalizeExecutionKey(executionKey);
  const response = await authorizedFetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Crypto-Auto-Trade-Key": normalizedKey,
    },
    body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      payload.message ?? payload.error ?? `HTTP_${response.status}`,
    );
  return payload as T;
}

async function fetchCandles(symbol: string, timeframe: Timeframe, limit = 240) {
  const payload = await apiGet<AnyObj>(
    `/crypto/futures/candles?symbol=${encodeURIComponent(symbol)}&granularity=${encodeURIComponent(timeframe)}&limit=${limit}`,
  );
  return normalizeCandles(
    Array.isArray(payload.candles) ? payload.candles : [],
  );
}

function normalizeTickers(payload: AnyObj | undefined) {
  return ((payload?.tickers ?? []) as AnyObj[])
    .map(
      (row) =>
        ({
          symbol: String(row.symbol ?? "").toUpperCase(),
          price: numberOf(row.price),
          markPrice: numberOf(row.markPrice ?? row.price),
          indexPrice: numberOf(row.indexPrice ?? row.markPrice ?? row.price),
          changePercent24h: numberOf(row.changePercent24h ?? row.changePercent),
          high24h: numberOf(row.high24h),
          low24h: numberOf(row.low24h),
          volume24h: numberOf(row.volume24h),
          tradingValue24h: numberOf(row.tradingValue24h),
          fundingRate: numberOf(row.fundingRate),
          openInterest: numberOf(row.openInterest),
          bidPrice: numberOf(row.bidPrice),
          askPrice: numberOf(row.askPrice),
        }) satisfies Ticker,
    )
    .filter((row) => row.symbol && row.markPrice > 0);
}

function formatPrice(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "-";
  if (Math.abs(value) >= 1000)
    return value.toLocaleString("ko-KR", { maximumFractionDigits: 2 });
  if (Math.abs(value) >= 1)
    return value.toLocaleString("ko-KR", { maximumFractionDigits: 4 });
  return value.toLocaleString("ko-KR", { maximumFractionDigits: 8 });
}

function formatPercent(value: number | null | undefined, digits = 2) {
  if (value == null || !Number.isFinite(value)) return "-";
  return `${value >= 0 ? "+" : ""}${value.toFixed(digits)}%`;
}

function toneClass(direction: Direction) {
  if (direction === "LONG")
    return "border-positive/30 bg-positive/10 text-positive";
  if (direction === "SHORT")
    return "border-destructive/30 bg-destructive/10 text-destructive";
  return "border-card-border bg-secondary text-muted-foreground";
}

function directionLabel(direction: Direction) {
  return direction === "LONG" ? "롱" : direction === "SHORT" ? "숏" : "관망";
}

function normalizeExecutionKey(value: unknown) {
  let normalized = String(value ?? "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
    .trim();

  const first = normalized.at(0);
  const last = normalized.at(-1);
  const quoted =
    (first === '"' && last === '"') ||
    (first === "'" && last === "'") ||
    (first === "`" && last === "`");

  if (quoted && normalized.length >= 2) {
    normalized = normalized.slice(1, -1).trim();
  }

  return normalized;
}

function loadExecutionKey() {
  if (typeof window === "undefined") return "";
  return normalizeExecutionKey(
    window.sessionStorage.getItem(EXECUTION_KEY_SESSION_KEY) ?? "",
  );
}

function saveExecutionKeyToSession(value: string) {
  if (typeof window === "undefined") return;
  const normalized = normalizeExecutionKey(value);
  if (normalized) {
    window.sessionStorage.setItem(EXECUTION_KEY_SESSION_KEY, normalized);
  } else {
    window.sessionStorage.removeItem(EXECUTION_KEY_SESSION_KEY);
  }
}

function buildAiTradeView(analysis: Analysis, timeframe: Timeframe) {
  const frameLabel = timeframeLabel(timeframe);
  const scoreGap = Math.abs(analysis.longScore - analysis.shortScore);
  if (analysis.direction === "LONG") {
    return {
      title: "매수 우위 · 눌림 또는 돌파 확인",
      summary: `${frameLabel} 기준 롱 ${analysis.longScore}점으로 숏보다 ${scoreGap}점 높습니다. ${formatPrice(analysis.support1)} 지지를 유지하면 매수 관점이며, ${formatPrice(analysis.resistance1)} 돌파 시 추세 강화를 확인합니다. 손절은 설정값과 지지 이탈을 함께 보세요.`,
    };
  }
  if (analysis.direction === "SHORT") {
    return {
      title: "매도 우위 · 반등 실패 또는 지지 이탈 확인",
      summary: `${frameLabel} 기준 숏 ${analysis.shortScore}점으로 롱보다 ${scoreGap}점 높습니다. ${formatPrice(analysis.resistance1)} 아래에서는 매도 관점이며, ${formatPrice(analysis.support1)} 이탈 시 하락 추세 강화를 확인합니다. 손절은 저항 회복과 설정값을 함께 보세요.`,
    };
  }
  return {
    title: "매수·매도 힘이 비슷해 관망",
    summary: `${frameLabel} 기준 롱 ${analysis.longScore}점, 숏 ${analysis.shortScore}점으로 방향 차이가 작습니다. ${formatPrice(analysis.resistance1)} 위 돌파는 롱 준비, ${formatPrice(analysis.support1)} 아래 이탈은 숏 준비 조건으로 보고 그 전에는 신규 진입을 보류합니다.`,
  };
}

function addLine(
  chart: IChartApi,
  rows: Array<{ time: Time; value: number }>,
  options: AnyObj,
) {
  const series = chart.addLineSeries({
    priceLineVisible: false,
    lastValueVisible: false,
    crosshairMarkerVisible: false,
    ...options,
  });
  series.setData(rows);
  return series;
}

function chartMarkers(candles: Candle[], analysis: Analysis) {
  const last = candles.at(-1);
  if (!last || analysis.direction === "WAIT") return [];
  return [
    {
      time: last.time,
      position: analysis.direction === "LONG" ? "belowBar" : "aboveBar",
      color: analysis.direction === "LONG" ? "#16a34a" : "#dc2626",
      shape: analysis.direction === "LONG" ? "arrowUp" : "arrowDown",
      text: `${directionLabel(analysis.direction)} ${Math.max(analysis.longScore, analysis.shortScore)}점`,
    },
  ];
}

function FuturesChart({
  candles,
  analysis,
  timeframe,
  overlays,
}: {
  candles: Candle[];
  analysis: Analysis;
  timeframe: Timeframe;
  overlays: Record<OverlayKey, boolean>;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !candles.length) return;
    const dark = document.documentElement.classList.contains("dark");
    const chart = createChart(container, {
      width: container.clientWidth,
      height: 390,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: dark ? "#cbd5e1" : "#475569",
        fontSize: 11,
      },
      grid: {
        vertLines: {
          color: dark ? "rgba(148,163,184,0.08)" : "rgba(100,116,139,0.10)",
        },
        horzLines: {
          color: dark ? "rgba(148,163,184,0.08)" : "rgba(100,116,139,0.10)",
        },
      },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: {
        borderVisible: false,
        scaleMargins: { top: 0.08, bottom: overlays.volume ? 0.22 : 0.08 },
      },
      timeScale: {
        borderVisible: false,
        timeVisible: timeframe !== "1D" && timeframe !== "1W",
        secondsVisible: false,
        rightOffset: 5,
        barSpacing: timeframe.includes("m") ? 8 : 7,
      },
      handleScroll: true,
      handleScale: true,
    });

    const candleSeries = chart.addCandlestickSeries({
      upColor: "#16a34a",
      downColor: "#dc2626",
      wickUpColor: "#16a34a",
      wickDownColor: "#dc2626",
      borderUpColor: "#16a34a",
      borderDownColor: "#dc2626",
      priceLineVisible: true,
      lastValueVisible: true,
    });
    candleSeries.setData(
      candles.map((row) => ({
        time: row.time,
        open: row.open,
        high: row.high,
        low: row.low,
        close: row.close,
      })),
    );

    if (overlays.ma5)
      addLine(chart, rollingSma(candles, 5), {
        color: "#f59e0b",
        lineWidth: 1,
        title: "MA5",
      });
    if (overlays.ma20)
      addLine(chart, rollingSma(candles, 20), {
        color: "#8b5cf6",
        lineWidth: 2,
        title: "MA20",
      });
    if (overlays.ma60)
      addLine(chart, rollingSma(candles, 60), {
        color: "#10b981",
        lineWidth: 1,
        title: "MA60",
      });
    if (overlays.bollinger) {
      const band = rollingBollinger(candles);
      addLine(chart, band.upper, {
        color: "rgba(14,165,233,0.75)",
        lineWidth: 1,
        title: "BB 상단",
      });
      addLine(chart, band.middle, {
        color: "rgba(14,165,233,0.35)",
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
        title: "BB 중심",
      });
      addLine(chart, band.lower, {
        color: "rgba(14,165,233,0.75)",
        lineWidth: 1,
        title: "BB 하단",
      });
    }
    if (overlays.vwap) {
      addLine(chart, rollingVwap(candles), {
        color: "#06b6d4",
        lineWidth: 2,
        lineStyle: LineStyle.Dashed,
        title: "VWAP",
      });
    }
    if (overlays.volume) {
      const volumeSeries = chart.addHistogramSeries({
        priceFormat: { type: "volume" },
        priceScaleId: "volume",
        lastValueVisible: false,
        priceLineVisible: false,
      });
      volumeSeries
        .priceScale()
        .applyOptions({ scaleMargins: { top: 0.8, bottom: 0 } });
      volumeSeries.setData(
        candles.map((row) => ({
          time: row.time,
          value: row.volume,
          color:
            row.close >= row.open
              ? "rgba(22,163,74,0.40)"
              : "rgba(220,38,38,0.40)",
        })),
      );
    }
    if (overlays.levels) {
      const lines = [
        {
          price: analysis.resistance2,
          color: "#f97316",
          title: "2차 저항",
          style: LineStyle.Dotted,
        },
        {
          price: analysis.resistance1,
          color: "#dc2626",
          title: "1차 저항",
          style: LineStyle.Dashed,
        },
        {
          price: analysis.support1,
          color: "#2563eb",
          title: "1차 지지",
          style: LineStyle.Dashed,
        },
        {
          price: analysis.support2,
          color: "#06b6d4",
          title: "2차 지지",
          style: LineStyle.Dotted,
        },
      ];
      for (const line of lines) {
        if (!(line.price > 0)) continue;
        candleSeries.createPriceLine({
          price: line.price,
          color: line.color,
          lineWidth: 1,
          lineStyle: line.style,
          axisLabelVisible: true,
          title: line.title,
        });
      }
    }
    if (overlays.arrows)
      candleSeries.setMarkers(chartMarkers(candles, analysis) as any);

    chart.timeScale().fitContent();
    const observer = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width;
      if (width) chart.applyOptions({ width: Math.max(1, width) });
    });
    observer.observe(container);
    return () => {
      observer.disconnect();
      chart.remove();
    };
  }, [analysis, candles, overlays, timeframe]);

  return <div ref={containerRef} className="h-[390px] w-full" />;
}

export function CryptoTradingWorkspace({
  viewMode,
  onViewModeChange,
  onBackToStock,
  onBackToSpot,
}: Props) {
  const assetMode = useAssetMode();
  const chartSectionRef = useRef<HTMLElement | null>(null);
  const scannerSectionRef = useRef<HTMLDivElement | null>(null);
  const autoSectionRef = useRef<HTMLElement | null>(null);
  const searchBoxRef = useRef<HTMLDivElement | null>(null);
  const [symbol, setSymbol] = useState(() => {
    if (typeof window === "undefined") return "BTCUSDT";
    return window.localStorage.getItem(SYMBOL_KEY) || "BTCUSDT";
  });
  const [query, setQuery] = useState("");
  const [timeframe, setTimeframe] = useState<Timeframe>("15m");
  const [visibleTimeframes, setVisibleTimeframes] = useState<Timeframe[]>(() =>
    loadJson<Timeframe[]>(VISIBLE_TIMEFRAMES_KEY, []),
  );
  const [settings, setSettings] = useState<AutoSettings>(() => loadSettings());
  const [executionKey, setExecutionKey] = useState(() => loadExecutionKey());
  const [showExecutionKey, setShowExecutionKey] = useState(false);
  const [executionKeySaved, setExecutionKeySaved] = useState(() =>
    Boolean(loadExecutionKey().trim()),
  );
  const [keyVerifying, setKeyVerifying] = useState(false);
  const [pendingPlan, setPendingPlan] = useState<PlanResponse | null>(null);
  const [watchPlan, setWatchPlan] = useState<WatchPlan | null>(null);
  const [planMenuOpen, setPlanMenuOpen] = useState(false);
  const [planViewerOpen, setPlanViewerOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<
    "open" | "close" | "configure" | "kill" | null
  >(null);
  const [message, setMessage] = useState("");
  const [feed, setFeed] = useState<FeedLine[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("tradingValue");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [scoreModal, setScoreModal] = useState<ScoreModalKind>(null);
  const [signalCandidate, setSignalCandidate] = useState<ScannerRow | null>(null);
  const [openSections, setOpenSections] = useState<OpenSections>(() => ({
    ...DEFAULT_OPEN_SECTIONS,
    ...loadJson<Partial<OpenSections>>(OPEN_SECTIONS_KEY, {}),
  }));
  const [favorites, setFavorites] = useState<string[]>(() =>
    loadJson<string[]>(FAVORITES_KEY, []),
  );
  const [alertRules, setAlertRules] = useState<Record<string, AssetAlertRule>>(
    () => loadJson<Record<string, AssetAlertRule>>(ALERTS_KEY, {}),
  );
  const [alertEditorSymbol, setAlertEditorSymbol] = useState<string | null>(
    null,
  );
  const [scannerCategory, setScannerCategory] =
    useState<ScannerCategory>("tradingValue");
  const [scannerDirection, setScannerDirection] =
    useState<ScannerDirection>("LONG");
  const [indicatorSettingsOpen, setIndicatorSettingsOpen] = useState(false);
  const [indicatorProfileTab, setIndicatorProfileTab] =
    useState<IndicatorProfileKey>("minute");
  const [indicatorProfiles, setIndicatorProfiles] = useState<IndicatorProfiles>(
    () => loadIndicatorProfiles(),
  );
  const [overlays, setOverlays] = useState<Record<OverlayKey, boolean>>(
    () => loadIndicatorProfiles().minute,
  );

  useEffect(() => {
    assetMode.setAsset("coin");
    assetMode.setCoinMarket("futures");
  }, []);

  useEffect(() => {
    const closeSearch = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (target && !searchBoxRef.current?.contains(target)) {
        setSearchOpen(false);
      }
    };
    const closeWithEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSearchOpen(false);
    };
    document.addEventListener("pointerdown", closeSearch);
    document.addEventListener("keydown", closeWithEscape);
    return () => {
      document.removeEventListener("pointerdown", closeSearch);
      document.removeEventListener("keydown", closeWithEscape);
    };
  }, []);

  useEffect(() => {
    const profileKey = indicatorProfileForTimeframe(timeframe);
    setIndicatorProfileTab(profileKey);
    setOverlays(indicatorProfiles[profileKey]);
  }, [timeframe, indicatorProfiles]);

  const status = useQuery({
    queryKey: ["crypto-status"],
    queryFn: () => apiGet<AnyObj>("/crypto/status"),
    refetchInterval: 30_000,
  });
  const tickersQuery = useQuery({
    queryKey: ["crypto-futures-tickers-live"],
    queryFn: () => apiGet<AnyObj>("/crypto/futures/tickers"),
    refetchInterval: 8_000,
    refetchIntervalInBackground: true,
  });
  const tickers = useMemo(
    () => normalizeTickers(tickersQuery.data),
    [tickersQuery.data],
  );
  const tickerMap = useMemo(
    () => new Map(tickers.map((row) => [row.symbol, row])),
    [tickers],
  );
  const selectedTicker = tickerMap.get(symbol) ?? null;
  const bitcoinTicker = tickerMap.get("BTCUSDT") ?? null;
  const positiveMarketRatio = tickers.length
    ? tickers.filter((row) => row.changePercent24h > 0).length / tickers.length
    : 0.5;
  const marketBias = clamp(
    (bitcoinTicker?.changePercent24h ?? 0) * 0.8 +
      (positiveMarketRatio - 0.5) * 12,
    -8,
    8,
  );

  const candlesQuery = useQuery({
    queryKey: ["crypto-futures-candles-live", symbol, timeframe],
    queryFn: () => fetchCandles(symbol, timeframe, 300),
    enabled: Boolean(symbol),
    refetchInterval: 10_000,
    refetchIntervalInBackground: true,
  });
  const candles = candlesQuery.data ?? [];
  const currentAnalysis = useMemo(
    () =>
      analyze(
        symbol,
        candles,
        selectedTicker,
        marketBias,
        numberOf(settings.minScore, 75),
      ),
    [candles, marketBias, selectedTicker, settings.minScore, symbol],
  );

  const scannerSymbols = useMemo(() => {
    const top = [...tickers]
      .sort((a, b) => b.tradingValue24h - a.tradingValue24h)
      .slice(0, 36)
      .map((row) => row.symbol);
    return Array.from(new Set([symbol, ...top])).filter(Boolean);
  }, [symbol, tickers]);
  const scannerKey = scannerSymbols.join("|");
  const scannerQuery = useQuery({
    queryKey: [
      "crypto-unified-search-analysis",
      timeframe,
      scannerKey,
      numberOf(settings.minScore, 75),
    ],
    queryFn: async () => {
      const rows = await Promise.allSettled(
        scannerSymbols.map(async (item) => {
          const rowCandles =
            item === symbol && candles.length
              ? candles
              : await fetchCandles(item, timeframe, 180);
          const ticker = tickerMap.get(item) ?? null;
          const rowAnalysis = analyze(
            item,
            rowCandles,
            ticker,
            marketBias,
            numberOf(settings.minScore, 75),
          );
          return rowAnalysis && ticker
            ? { ticker, analysis: rowAnalysis }
            : null;
        }),
      );
      return rows
        .map((row) => (row.status === "fulfilled" ? row.value : null))
        .filter(
          (row): row is { ticker: Ticker; analysis: Analysis } => row != null,
        )
        .map(
          (row, index) => ({ ...row, rank: index + 1 }) satisfies ScannerRow,
        );
    },
    enabled: scannerSymbols.length > 0,
    refetchInterval: 30_000,
    refetchIntervalInBackground: true,
  });
  const scannerRows = scannerQuery.data ?? [];
  const topSignalRows = useMemo(
    () => [...scannerRows]
      .sort((a, b) => Math.max(b.analysis.longScore, b.analysis.shortScore) - Math.max(a.analysis.longScore, a.analysis.shortScore) || Math.abs(b.analysis.longScore - b.analysis.shortScore) - Math.abs(a.analysis.longScore - a.analysis.shortScore))
      .slice(0, 10),
    [scannerRows],
  );
  const analysisMap = useMemo(
    () => new Map(scannerRows.map((row) => [row.ticker.symbol, row.analysis])),
    [scannerRows],
  );

  const autoStatus = useQuery({
    queryKey: ["crypto-auto-status", symbol],
    queryFn: () =>
      getProtected<AnyObj>(
        `/api/crypto/futures/auto/status?symbol=${encodeURIComponent(symbol)}`,
      ),
    refetchInterval: 10_000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
  });
  const account = useQuery({
    queryKey: ["crypto-futures-account"],
    queryFn: () => getProtected<AnyObj>("/api/crypto/futures/account"),
    refetchInterval: 10_000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    retry: 1,
  });
  const positionsQuery = useQuery({
    queryKey: ["crypto-futures-positions"],
    queryFn: () => getProtected<AnyObj>("/api/crypto/futures/positions"),
    refetchInterval: 15_000,
  });
  const positions = ((positionsQuery.data?.positions ?? []) as AnyObj[]).map(
    (row) =>
      ({
        symbol: String(row.symbol ?? ""),
        holdSide: String(row.holdSide ?? ""),
        total: numberOf(row.total),
        available: numberOf(row.available),
        openPriceAvg: numberOf(row.openPriceAvg),
        markPrice: numberOf(row.markPrice),
        unrealizedPL: numberOf(row.unrealizedPL),
        liquidationPrice: numberOf(row.liquidationPrice),
        leverage: numberOf(row.leverage),
        marginMode: String(row.marginMode ?? ""),
        marginSize: numberOf(row.marginSize),
        breakEvenPrice: numberOf(row.breakEvenPrice),
      }) satisfies Position,
  );

  const unifiedRows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const rows = tickers
      .filter((row) => !needle || row.symbol.toLowerCase().includes(needle))
      .map((ticker) => ({
        ticker,
        analysis: analysisMap.get(ticker.symbol) ?? null,
      }));

    const direction = sortDirection === "asc" ? 1 : -1;
    if (sortDirection !== "none") {
      rows.sort((a, b) => {
        if (sortKey === "symbol")
          return direction * a.ticker.symbol.localeCompare(b.ticker.symbol);
        const av =
          sortKey === "tradingValue"
            ? a.ticker.tradingValue24h
            : sortKey === "volume"
              ? a.ticker.volume24h
              : sortKey === "change"
                ? a.ticker.changePercent24h
                : sortKey === "aiLong"
                  ? (a.analysis?.longScore ?? -1)
                  : (a.analysis?.shortScore ?? -1);
        const bv =
          sortKey === "tradingValue"
            ? b.ticker.tradingValue24h
            : sortKey === "volume"
              ? b.ticker.volume24h
              : sortKey === "change"
                ? b.ticker.changePercent24h
                : sortKey === "aiLong"
                  ? (b.analysis?.longScore ?? -1)
                  : (b.analysis?.shortScore ?? -1);
        return (
          direction * (av - bv) ||
          b.ticker.tradingValue24h - a.ticker.tradingValue24h
        );
      });
    }
    return rows.slice(0, 60);
  }, [analysisMap, query, sortDirection, sortKey, tickers]);

  const perspectiveQuery = useQuery({
    queryKey: [
      "crypto-multi-horizon-analysis",
      symbol,
      numberOf(settings.minScore, 75),
    ],
    queryFn: async () => {
      const frames: Timeframe[] = ["15m", "4H", "1D"];
      const pairs = await Promise.all(
        frames.map(async (frame) => {
          const rows =
            frame === timeframe && candles.length
              ? candles
              : await fetchCandles(symbol, frame, 220);
          return [
            frame,
            analyze(
              symbol,
              rows,
              selectedTicker,
              marketBias,
              numberOf(settings.minScore, 75),
            ),
          ] as const;
        }),
      );
      return Object.fromEntries(pairs) as Partial<
        Record<Timeframe, Analysis | null>
      >;
    },
    enabled: Boolean(symbol),
    refetchInterval: 30_000,
    refetchIntervalInBackground: true,
  });

  const previousAnalysisRef = useRef<Analysis | null>(null);
  useEffect(() => {
    if (!currentAnalysis || !settings.monitorEnabled) return;
    const previous = previousAnalysisRef.current;
    previousAnalysisRef.current = currentAnalysis;
    const at = new Date();
    const lines: FeedLine[] = [];
    const push = (id: string, tone: FeedLine["tone"], text: string) =>
      lines.push({ id, at, tone, text });
    const baseId = `${symbol}:${timeframe}:${Math.floor(at.getTime() / 15_000)}`;

    if (!previous) {
      push(
        `${baseId}:start`,
        "INFO",
        `${timeframeLabel(timeframe)} 분석 시작 · 롱 ${currentAnalysis.longScore}점 / 숏 ${currentAnalysis.shortScore}점`,
      );
    } else {
      if (previous.direction !== currentAnalysis.direction) {
        push(
          `${baseId}:direction`,
          currentAnalysis.direction,
          `${directionLabel(previous.direction)} → ${directionLabel(currentAnalysis.direction)}로 관점 변경 · 롱 ${previous.longScore}→${currentAnalysis.longScore}, 숏 ${previous.shortScore}→${currentAnalysis.shortScore}`,
        );
      }
      if (Math.abs(currentAnalysis.longScore - previous.longScore) >= 5) {
        push(
          `${baseId}:long`,
          "LONG",
          `AI 롱 점수 ${previous.longScore}→${currentAnalysis.longScore} · ${currentAnalysis.longReasons[0] ?? "상승 조건 변화"}`,
        );
      }
      if (Math.abs(currentAnalysis.shortScore - previous.shortScore) >= 5) {
        push(
          `${baseId}:short`,
          "SHORT",
          `AI 숏 점수 ${previous.shortScore}→${currentAnalysis.shortScore} · ${currentAnalysis.shortReasons[0] ?? "하락 조건 변화"}`,
        );
      }
      if (previous.volumeRatio < 1.8 && currentAnalysis.volumeRatio >= 1.8) {
        push(
          `${baseId}:volume`,
          "INFO",
          `거래량 급증 · 최근 평균 대비 ${currentAnalysis.volumeRatio.toFixed(1)}배`,
        );
      }
      if ((previous.rsi ?? 50) < 70 && (currentAnalysis.rsi ?? 0) >= 70) {
        push(
          `${baseId}:rsi-high`,
          "SHORT",
          `RSI 과매수 구간 진입 · ${(currentAnalysis.rsi ?? 0).toFixed(1)}`,
        );
      }
      if ((previous.rsi ?? 50) > 30 && (currentAnalysis.rsi ?? 100) <= 30) {
        push(
          `${baseId}:rsi-low`,
          "LONG",
          `RSI 과매도 구간 진입 · ${(currentAnalysis.rsi ?? 0).toFixed(1)}`,
        );
      }
      const nearResistance =
        currentAnalysis.currentPrice >= currentAnalysis.resistance1 * 0.997;
      const wasNearResistance =
        previous.currentPrice >= previous.resistance1 * 0.997;
      if (!wasNearResistance && nearResistance)
        push(
          `${baseId}:resistance`,
          "INFO",
          `1차 저항 ${formatPrice(currentAnalysis.resistance1)} 접근 · 돌파 확정 전 추격 진입 주의`,
        );
      const nearSupport =
        currentAnalysis.currentPrice <= currentAnalysis.support1 * 1.003;
      const wasNearSupport = previous.currentPrice <= previous.support1 * 1.003;
      if (!wasNearSupport && nearSupport)
        push(
          `${baseId}:support`,
          "INFO",
          `1차 지지 ${formatPrice(currentAnalysis.support1)} 접근 · 지지 반응 또는 이탈 확인 필요`,
        );
    }
    if (!lines.length) return;
    setFeed((current) => {
      const seen = new Set(current.map((item) => item.text));
      return [
        ...lines.filter((item) => !seen.has(item.text)),
        ...current,
      ].slice(0, 80);
    });
  }, [
    currentAnalysis?.generatedAt,
    settings.monitorEnabled,
    symbol,
    timeframe,
  ]);

  useEffect(() => {
    if (!tickers.length) return;
    const nextRules = { ...alertRules };
    let changed = false;
    for (const [key, rule] of Object.entries(alertRules) as Array<
      [string, AssetAlertRule]
    >) {
      if (!key.startsWith("COIN:")) continue;
      const ticker = tickerMap.get(rule.symbol);
      if (!ticker) continue;
      let trigger = "";
      const target = Number(rule.targetPrice);
      if (rule.targetEnabled && Number.isFinite(target) && target > 0) {
        if (rule.targetDirection === "above" && ticker.markPrice >= target)
          trigger = `목표가격 ${formatPrice(target)} 이상 도달`;
        if (rule.targetDirection === "below" && ticker.markPrice <= target)
          trigger = `목표가격 ${formatPrice(target)} 이하 도달`;
      }
      const changeTarget = Number(rule.changePercent);
      if (
        !trigger &&
        rule.changeEnabled &&
        Number.isFinite(changeTarget) &&
        changeTarget >= 0
      ) {
        if (
          rule.changeDirection === "up" &&
          ticker.changePercent24h >= changeTarget
        )
          trigger = `등락률 +${changeTarget}% 이상 도달`;
        if (
          rule.changeDirection === "down" &&
          ticker.changePercent24h <= -changeTarget
        )
          trigger = `등락률 -${changeTarget}% 이하 도달`;
      }
      const triggerKey = trigger ? `${rule.symbol}:${trigger}` : "";
      if (trigger && rule.lastTriggeredKey !== triggerKey) {
        setMessage(`🔔 ${rule.symbol} ${trigger}`);
        if (
          typeof Notification !== "undefined" &&
          Notification.permission === "granted"
        ) {
          new Notification(`${rule.symbol} 알림`, { body: trigger });
        }
        nextRules[key] = { ...rule, lastTriggeredKey: triggerKey };
        changed = true;
      }
    }
    if (changed) setAlertRules(saveJson(ALERTS_KEY, nextRules));
  }, [tickersQuery.dataUpdatedAt]);

  const updateSettings = (patch: Partial<AutoSettings>) => {
    setSettings((current) => saveSettings({ ...current, ...patch }));
    setPendingPlan(null);
  };

  const chooseTimeframe = (next: Timeframe) => {
    setTimeframe(next);
    setPendingPlan(null);
    const profileKey = indicatorProfileForTimeframe(next);
    setIndicatorProfileTab(profileKey);
    setOverlays(indicatorProfiles[profileKey]);
  };

  const toggleProfileOverlay = (
    profileKey: IndicatorProfileKey,
    key: OverlayKey,
  ) => {
    setIndicatorProfiles((current) => {
      const next = saveIndicatorProfiles({
        ...current,
        [profileKey]: {
          ...current[profileKey],
          [key]: !current[profileKey][key],
        },
      });
      if (indicatorProfileForTimeframe(timeframe) === profileKey) {
        setOverlays(next[profileKey]);
      }
      return next;
    });
  };

  const selectSymbol = (next: string) => {
    const normalized = next.toUpperCase();
    setSymbol(normalized);
    setQuery("");
    setSearchOpen(false);
    setPendingPlan(null);
    if (typeof window !== "undefined")
      window.localStorage.setItem(SYMBOL_KEY, normalized);
    chartSectionRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  const changeView = (next: CryptoWorkspaceViewMode) => {
    // 최상단 탭을 누르면 부모 화면에서
    // 조건검색·신호검색기·자동매매 위치를 바꾸고
    // 아래 선택을 주식 → 국내로 초기화한다.
    // 현재 활성 탭을 다시 눌러도 같은 규칙을 적용한다.
    onViewModeChange(next);
  };

  const refreshAll = async () => {
    await Promise.allSettled([
      status.refetch(),
      tickersQuery.refetch(),
      candlesQuery.refetch(),
      scannerQuery.refetch(),
      autoStatus.refetch(),
      account.refetch(),
      positionsQuery.refetch(),
    ]);
  };

  const registerExecutionKey = async () => {
    if (keyVerifying) return;

    const normalized = normalizeExecutionKey(executionKey);
    if (!normalized) {
      setExecutionKeySaved(false);
      saveExecutionKeyToSession("");
      setMessage(
        "화면 맨 아래에서 자동매매 실행키를 입력하고 Enter를 눌러 확인하세요.",
      );
      return;
    }

    setKeyVerifying(true);
    setExecutionKey(normalized);
    setExecutionKeySaved(false);
    setPendingPlan(null);
    setMessage("서버에 설정된 자동매매 실행키와 일치하는지 확인 중입니다.");

    try {
      await postProtected<AnyObj>(
        "/api/crypto/futures/auto/verify-key",
        {},
        normalized,
      );
      saveExecutionKeyToSession(normalized);
      setExecutionKeySaved(true);
      setMessage(
        "실행키 확인이 완료됐습니다. 이제 거래소 설정계획과 주문계획에 자동 사용됩니다.",
      );
      await Promise.allSettled([
        autoStatus.refetch(),
        account.refetch(),
        positionsQuery.refetch(),
      ]);
    } catch (error) {
      saveExecutionKeyToSession("");
      setExecutionKeySaved(false);
      setMessage(
        error instanceof Error
          ? `${error.message} Replit Secrets의 CRYPTO_AUTO_TRADE_KEY 값을 확인한 뒤 Stop → Run 해주세요.`
          : "자동매매 실행키 확인에 실패했습니다.",
      );
    } finally {
      setKeyVerifying(false);
    }
  };

  const changeExecutionMode = (next: ExecutionMode) => {
    if (next === "REAL") {
      const confirmed = window.confirm(
        "실주문 모드는 최종 승인 시 실제 비트겟 주문을 전송할 수 있습니다. 먼저 모의매매와 긴급정지 상태를 확인했습니까?",
      );
      if (!confirmed) return;
    }
    updateSettings({ executionMode: next });
    setMessage(
      next === "PAPER"
        ? "모의매매 모드입니다. 최종 승인해도 실제 비트겟 주문은 전송되지 않습니다."
        : "실주문 모드입니다. 서버 실주문 스위치와 긴급정지 해제, 주문별 최종 승인이 모두 필요합니다.",
    );
  };

  const updateKillSwitch = async (enabled: boolean) => {
    if (!executionKeySaved || !normalizeExecutionKey(executionKey)) {
      setMessage(
        "화면 맨 아래에서 실행키를 입력하고 Enter를 눌러 서버 확인을 완료하세요.",
      );
      return;
    }
    if (!enabled) {
      const confirmed = window.confirm(
        "긴급정지를 해제하면 실주문 모드에서 승인된 주문을 실행할 수 있습니다. 모의매매와 계좌 설정을 확인했습니까?",
      );
      if (!confirmed) return;
    }
    setPendingAction("kill");
    try {
      const result = await postProtected<AnyObj>(
        "/api/crypto/futures/auto/kill-switch",
        {
          enabled,
          reason: enabled
            ? "사용자가 앱에서 긴급정지"
            : "사용자가 안전 확인 후 긴급정지 해제",
        },
        executionKey,
      );
      setMessage(
        String(
          result.journal?.message ??
            (enabled ? "긴급정지가 켜졌습니다." : "긴급정지가 해제됐습니다."),
        ),
      );
      if (enabled) {
        setPendingPlan(null);
        setPlanViewerOpen(false);
      }
      await autoStatus.refetch();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "긴급정지 변경 실패");
    } finally {
      setPendingAction(null);
    }
  };

  const createWatchPlan = () => {
    if (!validateSettings(false)) return;
    if (!currentAnalysis) {
      setMessage("차트 분석이 완료된 뒤 관망 준비계획서를 만들 수 있습니다.");
      return;
    }
    const plan: WatchPlan = {
      kind: "WATCH",
      symbol,
      timeframe,
      direction: "WAIT",
      longScore: currentAnalysis.longScore,
      shortScore: currentAnalysis.shortScore,
      minimumScore: settings.minScore,
      supportTrigger: currentAnalysis.support1,
      resistanceTrigger: currentAnalysis.resistance1,
      marginAmountUSDT: settings.marginAmountUSDT,
      leverage: settings.leverage,
      stopLossPercent: settings.stopLossPercent,
      targetProfitPercent: settings.targetProfitPercent,
      availableUSDT: accountRow ? numberOf(accountRow.available) : null,
      accountEquityUSDT: accountRow ? numberOf(accountRow.accountEquity) : null,
      reasons: [
        ...currentAnalysis.longReasons.slice(0, 2),
        ...currentAnalysis.shortReasons.slice(0, 2),
      ],
      createdAt: new Date().toISOString(),
    };
    setWatchPlan(plan);
    setPendingPlan(null);
    setPlanMenuOpen(false);
    setPlanViewerOpen(true);
    setMessage(
      "관망 준비계획서를 만들었습니다. 실제 주문은 전송되지 않습니다.",
    );
  };

  const openPlanViewer = () => {
    if (!pendingPlan && !watchPlan) {
      setMessage("먼저 계획서를 만들어 주세요.");
      return;
    }
    setPlanMenuOpen(false);
    setPlanViewerOpen(true);
  };

  const buildOpenPlan = async () => {
    if (!validateSettings(false)) return null;
    if (!currentAnalysis) {
      setMessage("차트 분석이 완료된 뒤 주문계획을 만들 수 있습니다.");
      return null;
    }
    if (currentAnalysis.direction === "WAIT") {
      createWatchPlan();
      return null;
    }
    if (!executionKeySaved || !normalizeExecutionKey(executionKey)) {
      setMessage(
        "화면 맨 아래에서 실행키를 입력하고 Enter를 눌러 서버 확인을 완료하세요.",
      );
      return null;
    }
    setPendingAction("open");
    setMessage("주문 직전 가격·계약규격·보유 포지션을 검사하는 중입니다.");
    try {
      const direction = currentAnalysis.direction;
      const result = await postProtected<PlanResponse>(
        "/api/crypto/futures/auto/plan",
        {
          symbol,
          direction,
          executionMode: settings.executionMode,
          positionMode: settings.positionMode,
          marginMode: settings.marginMode,
          leverage: settings.leverage,
          marginAmountUSDT: settings.marginAmountUSDT,
          score:
            direction === "LONG"
              ? currentAnalysis.longScore
              : currentAnalysis.shortScore,
          oppositeScore:
            direction === "LONG"
              ? currentAnalysis.shortScore
              : currentAnalysis.longScore,
          minScore: settings.minScore,
          stopLossPercent: settings.stopLossPercent,
          targetProfitPercent: settings.targetProfitPercent,
          maxOpenPositions: settings.maxOpenPositions,
          maxDailyOrders: settings.maxDailyOrders,
          btcChangePercent24h: bitcoinTicker?.changePercent24h ?? null,
          reasons:
            direction === "LONG"
              ? currentAnalysis.longReasons
              : currentAnalysis.shortReasons,
        },
        executionKey,
      );
      setPendingPlan(result);
      setWatchPlan(null);
      setPlanMenuOpen(false);
      setPlanViewerOpen(true);
      setMessage(
        "주문계획이 생성됐습니다. 작은 계획서 창에서 수량·손절·익절을 확인한 뒤 최종 승인하세요.",
      );
      return result;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "주문계획 생성 실패");
      return null;
    } finally {
      setPendingAction(null);
    }
  };

  const approveOpen = async () => {
    if (!pendingPlan?.approvalToken) return;
    const planExecutionMode = String(
      pendingPlan.plan?.executionMode ?? settings.executionMode,
    ).toUpperCase();
    const confirmed = window.confirm(
      planExecutionMode === "PAPER"
        ? `${String(pendingPlan.plan?.symbol ?? symbol)} ${String(pendingPlan.plan?.direction ?? "")} 모의매매를 체결가 기준으로 기록합니다. 실제 주문은 전송되지 않습니다. 계속하시겠습니까?`
        : `${String(pendingPlan.plan?.symbol ?? symbol)} ${String(pendingPlan.plan?.direction ?? "")} 주문을 실제 비트겟 계정으로 전송합니다. 계속하시겠습니까?`,
    );
    if (!confirmed) return;
    setPendingAction("open");
    try {
      const result = await postProtected<AnyObj>(
        "/api/crypto/futures/auto/execute",
        { approvalToken: pendingPlan.approvalToken },
        executionKey,
      );
      setMessage(
        String(
          result.journal?.message ??
            (result.simulated
              ? "모의매매가 기록됐습니다."
              : "주문이 전송됐습니다."),
        ),
      );
      setPlanViewerOpen(false);
      setPendingPlan(null);
      await Promise.allSettled([
        positionsQuery.refetch(),
        autoStatus.refetch(),
        account.refetch(),
      ]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "주문 전송 실패");
      setPendingPlan(null);
    } finally {
      setPendingAction(null);
    }
  };

  const buildConfigurePlan = async () => {
    if (!validateSettings(true)) return;
    if (!executionKeySaved || !normalizeExecutionKey(executionKey)) {
      setMessage(
        "화면 맨 아래에서 실행키를 입력하고 Enter를 눌러 서버 확인을 완료하세요.",
      );
      return;
    }
    setPendingAction("configure");
    try {
      const result = await postProtected<PlanResponse>(
        "/api/crypto/futures/auto/configure-plan",
        {
          symbol,
          positionMode: settings.positionMode,
          marginMode: settings.marginMode,
          leverage: settings.leverage,
        },
        executionKey,
      );
      setPendingPlan(result);
      setWatchPlan(null);
      setPlanViewerOpen(true);
      setMessage(
        "거래소 설정계획을 만들었습니다. 작은 창에서 내용을 확인한 뒤 승인하세요.",
      );
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "설정계획 생성 실패");
    } finally {
      setPendingAction(null);
    }
  };

  const approveConfigure = async () => {
    if (!pendingPlan?.approvalToken || pendingPlan.plan?.kind !== "CONFIGURE")
      return;
    const confirmed = window.confirm(
      "비트겟 포지션 모드·마진 모드·레버리지 설정을 실제 계정에 적용합니다. 계속하시겠습니까?",
    );
    if (!confirmed) return;
    setPendingAction("configure");
    try {
      const result = await postProtected<AnyObj>(
        "/api/crypto/futures/auto/configure",
        { approvalToken: pendingPlan.approvalToken },
        executionKey,
      );
      setMessage(
        String(result.journal?.message ?? "거래소 설정을 적용했습니다."),
      );
      setPlanViewerOpen(false);
      setPendingPlan(null);
      await Promise.allSettled([autoStatus.refetch(), account.refetch()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "거래소 설정 실패");
      setPendingPlan(null);
    } finally {
      setPendingAction(null);
    }
  };

  const buildClosePlan = async (position: Position) => {
    if (!executionKeySaved || !normalizeExecutionKey(executionKey)) {
      setMessage(
        "화면 맨 아래에서 실행키를 입력하고 Enter를 눌러 서버 확인을 완료하세요.",
      );
      return;
    }
    setPendingAction("close");
    try {
      const result = await postProtected<PlanResponse>(
        "/api/crypto/futures/auto/close-plan",
        {
          symbol: position.symbol,
          holdSide: position.holdSide,
          positionMode: settings.positionMode,
          reason: "사용자 수동 종료 승인",
        },
        executionKey,
      );
      setPendingPlan(result);
      setWatchPlan(null);
      setPlanViewerOpen(true);
      setMessage(
        "포지션 종료계획이 생성됐습니다. 작은 창에서 방향과 수량을 확인한 뒤 최종 승인하세요.",
      );
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "종료계획 생성 실패");
    } finally {
      setPendingAction(null);
    }
  };

  const approveClose = async () => {
    if (!pendingPlan?.approvalToken || pendingPlan.plan?.kind !== "CLOSE")
      return;
    const confirmed = window.confirm(
      `${String(pendingPlan.plan?.symbol ?? "")} 포지션을 시장가로 종료합니다. 계속하시겠습니까?`,
    );
    if (!confirmed) return;
    setPendingAction("close");
    try {
      const result = await postProtected<AnyObj>(
        "/api/crypto/futures/auto/close",
        { approvalToken: pendingPlan.approvalToken },
        executionKey,
      );
      setMessage(
        String(result.journal?.message ?? "포지션 종료 요청을 전송했습니다."),
      );
      setPlanViewerOpen(false);
      setPendingPlan(null);
      await Promise.allSettled([
        positionsQuery.refetch(),
        autoStatus.refetch(),
        account.refetch(),
      ]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "포지션 종료 실패");
      setPendingPlan(null);
    } finally {
      setPendingAction(null);
    }
  };

  const cycleSort = (nextKey: SortKey) => {
    if (sortKey !== nextKey) {
      setSortKey(nextKey);
      setSortDirection(nextKey === "symbol" ? "asc" : "desc");
      return;
    }
    setSortDirection((current) =>
      current === "none"
        ? nextKey === "symbol"
          ? "asc"
          : "desc"
        : current === "desc"
          ? "asc"
          : current === "asc"
            ? "none"
            : "desc",
    );
  };

  const toggleSection = (key: SectionKey) => {
    setOpenSections((current) =>
      saveJson(OPEN_SECTIONS_KEY, { ...current, [key]: !current[key] }),
    );
  };

  const toggleVisibleTimeframe = (value: Timeframe) => {
    setVisibleTimeframes((current) => {
      const next = current.includes(value)
        ? current.filter((item) => item !== value)
        : [...current, value];
      return saveJson(VISIBLE_TIMEFRAMES_KEY, next);
    });
  };

  const toggleFavorite = (value: string) => {
    const key = `COIN:${value}`;
    setFavorites((current) => {
      const next = current.includes(key)
        ? current.filter((item) => item !== key)
        : [...current, key];
      return saveJson(FAVORITES_KEY, next);
    });
  };

  const currentAlertRule: AssetAlertRule = alertEditorSymbol
    ? (alertRules[`COIN:${alertEditorSymbol}`] ?? {
        symbol: alertEditorSymbol,
        targetEnabled: false,
        targetDirection: "above",
        targetPrice: "",
        changeEnabled: false,
        changeDirection: "up",
        changePercent: "",
        newsEnabled: false,
      })
    : {
        symbol,
        targetEnabled: false,
        targetDirection: "above",
        targetPrice: "",
        changeEnabled: false,
        changeDirection: "up",
        changePercent: "",
        newsEnabled: false,
      };

  const saveAlertRule = (rule: AssetAlertRule) => {
    const key = `COIN:${rule.symbol}`;
    setAlertRules((current) =>
      saveJson(ALERTS_KEY, { ...current, [key]: rule }),
    );
    setAlertEditorSymbol(null);
    setMessage(`${rule.symbol} 알림 설정을 저장했습니다.`);
  };

  const validateSettings = (configureOnly = false) => {
    const fields: Array<[string, number]> = configureOnly
      ? [["레버리지", settings.leverage]]
      : [
          ["레버리지", settings.leverage],
          ["1회 증거금", settings.marginAmountUSDT],
          ["최소 신호점수", settings.minScore],
          ["손절률", settings.stopLossPercent],
          ["목표 수익률", settings.targetProfitPercent],
          ["최대 동시보유", settings.maxOpenPositions],
          ["하루 신규주문", settings.maxDailyOrders],
        ];
    const missing = fields
      .filter(([, value]) => !Number.isFinite(value) || value <= 0)
      .map(([label]) => label);
    if (missing.length) {
      setMessage(
        `${missing.join(", ")} 값을 먼저 입력하세요. 숫자 입력칸은 빈칸에서 바로 0.5처럼 입력할 수 있습니다.`,
      );
      return false;
    }
    return true;
  };

  const serverConnected = Boolean(status.data?.bitget?.ok);
  const privateConfigured = Boolean(status.data?.bitget?.privateKeyConfigured);
  const accountRow =
    ((account.data?.accounts ?? []) as AnyObj[]).find(
      (row) => String(row.marginCoin ?? "").toUpperCase() === "USDT",
    ) ?? null;
  const availableUSDT = accountRow ? numberOf(accountRow.available) : null;
  const accountEquityUSDT = accountRow
    ? numberOf(accountRow.accountEquity)
    : null;
  const unrealizedPLUSDT = accountRow
    ? numberOf(accountRow.unrealizedPL)
    : null;
  const isolatedAvailableUSDT = accountRow
    ? numberOf(accountRow.isolatedMaxAvailable)
    : null;
  const crossedAvailableUSDT = accountRow
    ? numberOf(accountRow.crossedMaxAvailable)
    : null;
  const accountUpdatedAt = String(account.data?.updatedAt ?? "");
  const aiTradeView = currentAnalysis
    ? buildAiTradeView(currentAnalysis, timeframe)
    : null;
  const planKind = String(pendingPlan?.plan?.kind ?? watchPlan?.kind ?? "");
  const killSwitchEnabled = autoStatus.data
    ? Boolean(autoStatus.data.killSwitch)
    : true;
  const exchangeAccount = (autoStatus.data?.exchangeAccount ??
    null) as AnyObj | null;
  const exchangePositionMode = String(
    exchangeAccount?.posMode ?? autoStatus.data?.lastAccountMode ?? "-",
  );
  const exchangeMarginMode = String(
    exchangeAccount?.marginMode ?? autoStatus.data?.lastMarginMode ?? "-",
  );
  const lastSyncAt = String(autoStatus.data?.lastSyncAt ?? "");

  return (
    <div className="h-full overflow-y-auto overscroll-contain bg-background">
      <header className="border-b border-card-border px-4 pb-3 pt-4">
        <div className="flex items-center gap-3">
          <h1 className="flex-1 text-center text-xl font-black">기술</h1>
          <button
            type="button"
            onClick={() => void refreshAll()}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-card-border bg-card"
          >
            <RefreshCw
              className={cn(
                "h-4 w-4",
                (tickersQuery.isFetching || candlesQuery.isFetching) &&
                  "animate-spin",
              )}
            />
          </button>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <TopTab
            active={viewMode === "condition"}
            onClick={() => changeView("condition")}
          >
            조건검색
          </TopTab>
          <TopTab
            active={viewMode === "chart"}
            onClick={() => changeView("chart")}
          >
            신호검색기
          </TopTab>
          <TopTab
            active={viewMode === "auto"}
            onClick={() => changeView("auto")}
          >
            자동매매
          </TopTab>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <TopTab active={false} onClick={onBackToStock}>
            주식
          </TopTab>
          <TopTab active onClick={() => undefined}>
            코인
          </TopTab>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <TopTab active={false} onClick={onBackToSpot}>현물</TopTab>
          <TopTab active onClick={() => undefined}>비트겟</TopTab>
        </div>
      </header>

      <main className="space-y-4 px-4 pb-28 pt-4">
        <div ref={scannerSectionRef} className={viewMode === "auto" ? "hidden" : ""}>
          <CollapsibleSectionCard
            title={viewMode === "chart" ? "종목 롱·숏 분석기" : "통합 조건검색"}
            subtitle={viewMode === "chart" ? "종목 검색 · AI 롱·숏 강도가 높은 순서대로 최대 10종목" : "종목명·거래대금·거래량·등락률·AI 롱·AI 숏 정렬"}
            open={openSections.search}
            onToggle={() => toggleSection("search")}
          >
            <div ref={searchBoxRef} className="relative">
              <label className="flex h-11 items-center gap-2 rounded-2xl border border-card-border bg-background px-3">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input
                  value={query}
                  onFocus={() => setSearchOpen(true)}
                  onChange={(event) => {
                    setQuery(event.target.value);
                    setSearchOpen(true);
                  }}
                  placeholder=""
                  className="min-w-0 flex-1 bg-transparent text-sm font-bold outline-none"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    aria-label="검색어 지우기"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={(event) => {
                    event.preventDefault();
                    setSearchOpen((current) => !current);
                  }}
                  className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground"
                >
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 transition-transform",
                      searchOpen && "rotate-180",
                    )}
                  />
                </button>
              </label>
              {searchOpen && (
                <div className="absolute left-0 right-0 top-12 z-40 max-h-[460px] overflow-auto rounded-2xl border border-card-border bg-card p-2 shadow-2xl">
                  <div className="min-w-[720px]">
                    <div className="grid grid-cols-[160px_110px_100px_90px_80px_80px] items-center gap-2 border-b border-card-border px-2 pb-2">
                      <SortHeader
                        label="종목명"
                        active={sortKey === "symbol"}
                        direction={
                          sortKey === "symbol" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("symbol")}
                      />
                      <SortHeader
                        label="거래대금"
                        active={sortKey === "tradingValue"}
                        direction={
                          sortKey === "tradingValue" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("tradingValue")}
                      />
                      <SortHeader
                        label="거래량"
                        active={sortKey === "volume"}
                        direction={
                          sortKey === "volume" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("volume")}
                      />
                      <SortHeader
                        label="등락률"
                        active={sortKey === "change"}
                        direction={
                          sortKey === "change" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("change")}
                      />
                      <SortHeader
                        label="AI 롱"
                        active={sortKey === "aiLong"}
                        direction={
                          sortKey === "aiLong" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("aiLong")}
                      />
                      <SortHeader
                        label="AI 숏"
                        active={sortKey === "aiShort"}
                        direction={
                          sortKey === "aiShort" ? sortDirection : "none"
                        }
                        onClick={() => cycleSort("aiShort")}
                      />
                    </div>
                    <div className="divide-y divide-card-border">
                      {unifiedRows.map(({ ticker, analysis }) => {
                        const favoriteKey = `COIN:${ticker.symbol}`;
                        return (
                          <div
                            key={ticker.symbol}
                            className="grid grid-cols-[160px_110px_100px_90px_80px_80px] items-center gap-2 px-2 py-2.5 text-xs hover:bg-secondary/60"
                          >
                            <div className="flex min-w-0 items-center gap-1">
                              <button
                                type="button"
                                onClick={(event) => {
                                  event.stopPropagation();
                                  toggleFavorite(ticker.symbol);
                                }}
                                className="shrink-0"
                                aria-label="즐겨찾기"
                              >
                                <Star
                                  className={cn(
                                    "h-4 w-4",
                                    favorites.includes(favoriteKey)
                                      ? "fill-warning text-warning"
                                      : "text-muted-foreground",
                                  )}
                                />
                              </button>
                              <button
                                type="button"
                                onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                                className="truncate font-black"
                              >
                                {ticker.symbol}
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setAlertEditorSymbol(ticker.symbol)
                                }
                                className="shrink-0"
                                aria-label="알림 설정"
                              >
                                <Bell className="h-3.5 w-3.5 text-muted-foreground" />
                              </button>
                            </div>
                            <button
                              type="button"
                              onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                              className="text-right font-bold"
                            >
                              {formatCompact(ticker.tradingValue24h)}
                            </button>
                            <button
                              type="button"
                              onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                              className="text-right font-bold"
                            >
                              {formatCompact(ticker.volume24h)}
                            </button>
                            <button
                              type="button"
                              onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                              className={cn(
                                "text-right font-black",
                                ticker.changePercent24h >= 0
                                  ? "text-positive"
                                  : "text-destructive",
                              )}
                            >
                              {formatPercent(ticker.changePercent24h)}
                            </button>
                            <button
                              type="button"
                              onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                              className="text-right font-black text-positive"
                            >
                              {analysis?.longScore ?? "-"}
                            </button>
                            <button
                              type="button"
                              onClick={() => analysis && setSignalCandidate({ ticker, analysis, rank: 0 })}
                              className="text-right font-black text-destructive"
                            >
                              {analysis?.shortScore ?? "-"}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  {!unifiedRows.length && (
                    <p className="p-5 text-center text-xs font-bold text-muted-foreground">
                      검색 결과가 없습니다.
                    </p>
                  )}
                  <button
                    type="button"
                    onClick={() => setSearchOpen(false)}
                    className="sticky bottom-0 mt-2 w-full rounded-xl bg-secondary py-2 text-xs font-black"
                  >
                    목록 닫기
                  </button>
                </div>
              )}
            </div>
            <p className="mt-2 text-[10px] font-bold text-muted-foreground">
              열 제목을 누르면 높은순/낮은순, 종목명은 A→Z/Z→A/기본순으로
              바뀝니다.
            </p>
            {viewMode === "chart" && (
              <div className="mt-3 space-y-2">
                {topSignalRows.map((row, index) => (
                  <button key={row.ticker.symbol} type="button" onClick={() => selectSymbol(row.ticker.symbol)} className={cn("w-full rounded-2xl border p-3 text-left", symbol === row.ticker.symbol ? "border-primary bg-primary/5" : "border-card-border bg-background")}>
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0"><p className="truncate text-sm font-black">{index + 1}위 · {row.ticker.symbol}</p><p className="mt-1 text-[10px] font-bold text-muted-foreground">{directionLabel(row.analysis.direction)} · {formatPercent(row.ticker.changePercent24h)}</p></div>
                      <div className="shrink-0 text-right"><p className="text-[10px] font-black text-positive">롱 {row.analysis.longScore}</p><p className="mt-1 text-[10px] font-black text-destructive">숏 {row.analysis.shortScore}</p></div>
                    </div>
                  </button>
                ))}
                {!topSignalRows.length && <LoadingBox text="상위 10종목 분석 중입니다." />}
              </div>
            )}
          </CollapsibleSectionCard>
        </div>

        <div className={cn("space-y-4", viewMode !== "chart" && "hidden")}>
        <section
          ref={chartSectionRef}
          className="scroll-mt-4 overflow-hidden rounded-3xl border border-card-border bg-card shadow-sm"
        >
          <div className="border-b border-card-border p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleFavorite(symbol)}
                    aria-label="즐겨찾기"
                  >
                    <Star
                      className={cn(
                        "h-5 w-5",
                        favorites.includes(`COIN:${symbol}`)
                          ? "fill-warning text-warning"
                          : "text-muted-foreground",
                      )}
                    />
                  </button>
                  <h2 className="truncate text-lg font-black">{symbol}</h2>
                  <span className="rounded-full bg-secondary px-2 py-1 text-[9px] font-black">
                    {timeframeLabel(timeframe)}
                  </span>
                </div>

              </div>
              <div className="flex items-center gap-2 text-right">
                <div>
                  <p className="text-lg font-black">
                    {formatPrice(
                      selectedTicker?.markPrice ??
                        currentAnalysis?.currentPrice,
                    )}
                  </p>
                  <p
                    className={cn(
                      "text-xs font-black",
                      (selectedTicker?.changePercent24h ?? 0) >= 0
                        ? "text-positive"
                        : "text-destructive",
                    )}
                  >
                    {formatPercent(selectedTicker?.changePercent24h)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setAlertEditorSymbol(symbol)}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-card-border bg-background"
                  aria-label="가격 알림"
                >
                  <Bell className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {visibleTimeframes.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => chooseTimeframe(item)}
                  className={cn(
                    "rounded-xl border px-3 py-2 text-xs font-black",
                    timeframe === item
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-card-border bg-background text-muted-foreground",
                  )}
                >
                  {timeframeLabel(item)}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setIndicatorSettingsOpen((current) => !current)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-card-border bg-background px-3 py-2 text-xs font-black text-muted-foreground"
              >
                <Settings2 className="h-4 w-4" />
                {visibleTimeframes.length ? "환경설정" : "봉 설정"}
              </button>
            </div>

            {indicatorSettingsOpen && (
              <div className="mt-3 space-y-4 rounded-2xl border border-card-border bg-background p-3">
                <div>
                  <p className="text-[10px] font-black text-primary">
                    차트 위에 표시할 봉
                  </p>
                  <p className="mt-1 text-[9px] font-bold text-muted-foreground">
                    선택한 봉만 차트 위에 표시됩니다. 아무것도 선택하지 않으면
                    봉 설정 버튼만 남습니다.
                  </p>
                  <div className="mt-3 space-y-3">
                    {TIMEFRAME_GROUPS.map((group) => (
                      <div key={group.key}>
                        <p className="mb-2 text-[10px] font-black text-muted-foreground">
                          {group.label}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {TIMEFRAMES.filter(
                            (item) => item.group === group.key,
                          ).map((item) => (
                            <button
                              key={item.key}
                              type="button"
                              onClick={() => toggleVisibleTimeframe(item.key)}
                              className={cn(
                                "rounded-full border px-3 py-1.5 text-[10px] font-black",
                                visibleTimeframes.includes(item.key)
                                  ? "border-primary bg-primary/10 text-primary"
                                  : "border-card-border bg-card text-muted-foreground",
                              )}
                            >
                              {visibleTimeframes.includes(item.key) ? "✓ " : ""}
                              {item.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="border-t border-card-border pt-3">
                  <div className="flex gap-2 overflow-x-auto">
                    {INDICATOR_PROFILE_TABS.map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => setIndicatorProfileTab(item.key)}
                        className={cn(
                          "shrink-0 rounded-full border px-3 py-1.5 text-[10px] font-black",
                          indicatorProfileTab === item.key
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-card-border bg-card text-muted-foreground",
                        )}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {OVERLAYS.map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() =>
                          toggleProfileOverlay(indicatorProfileTab, item.key)
                        }
                        className={cn(
                          "rounded-full border px-3 py-1.5 text-[10px] font-black",
                          indicatorProfiles[indicatorProfileTab][item.key]
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-card-border bg-card text-muted-foreground",
                        )}
                      >
                        {indicatorProfiles[indicatorProfileTab][item.key]
                          ? "✓ "
                          : ""}
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2 rounded-xl bg-secondary p-2 text-[10px] font-bold text-muted-foreground">
                  <Info className="h-4 w-4 shrink-0" />
                  8시간·5/10/15/30일·년봉은 서버가 기존 봉을 합쳐 생성합니다.
                </div>
              </div>
            )}
          </div>
          <div className="min-h-[390px] bg-background/30">
            {candlesQuery.isLoading ? (
              <LoadingBox text="차트 봉을 불러오는 중입니다." />
            ) : candlesQuery.isError ? (
              <ErrorBox
                text={
                  candlesQuery.error instanceof Error
                    ? candlesQuery.error.message
                    : "차트 조회 실패"
                }
              />
            ) : currentAnalysis ? (
              <FuturesChart
                candles={candles}
                analysis={currentAnalysis}
                timeframe={timeframe}
                overlays={overlays}
              />
            ) : (
              <LoadingBox text="분석할 봉 데이터가 충분하지 않습니다." />
            )}
          </div>
        </section>

        <CollapsibleSectionCard
          title="롱·숏 점수와 종합신호"
          subtitle="카드를 누르면 점수 근거와 단타·스윙·중장기 관점 표시"
          open={openSections.scores}
          onToggle={() => toggleSection("scores")}
        >
          {currentAnalysis ? (
            <div className="grid grid-cols-3 gap-2">
              <ScoreButton
                label="롱 점수"
                value={`${currentAnalysis.longScore}`}
                tone="long"
                active={currentAnalysis.direction === "LONG"}
                onClick={() => setScoreModal("LONG")}
              />
              <ScoreButton
                label="숏 점수"
                value={`${currentAnalysis.shortScore}`}
                tone="short"
                active={currentAnalysis.direction === "SHORT"}
                onClick={() => setScoreModal("SHORT")}
              />
              <ScoreButton
                label="종합신호"
                value={directionLabel(currentAnalysis.direction)}
                tone="total"
                active
                onClick={() => setScoreModal("TOTAL")}
              />
            </div>
          ) : (
            <LoadingBox text="점수 계산 중입니다." />
          )}
        </CollapsibleSectionCard>

        <CollapsibleSectionCard
          title="차트 AI 분석"
          subtitle="의미 있는 변화가 생길 때만 갱신 · 중복 알림 방지"
          open={openSections.ai}
          onToggle={() => toggleSection("ai")}
        >
          {currentAnalysis && aiTradeView && (
            <div className="rounded-2xl border border-card-border bg-background p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-black">{aiTradeView.title}</p>
                <span
                  className={cn(
                    "rounded-full border px-2 py-1 text-[9px] font-black",
                    toneClass(currentAnalysis.direction),
                  )}
                >
                  {directionLabel(currentAnalysis.direction)}
                </span>
              </div>
              <p className="mt-2 text-[11px] font-bold leading-5 text-muted-foreground">
                {aiTradeView.summary}
              </p>
            </div>
          )}
          <div className="mt-3 max-h-80 space-y-2 overflow-y-auto">
            {feed.map((item) => (
              <article
                key={item.id}
                className="grid grid-cols-[72px_minmax(0,1fr)] gap-2 rounded-2xl bg-background p-3"
              >
                <time className="text-[9px] font-bold text-muted-foreground">
                  {item.at.toLocaleTimeString("ko-KR", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  })}
                </time>
                <div>
                  <span
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-[9px] font-black",
                      toneClass(item.tone === "INFO" ? "WAIT" : item.tone),
                    )}
                  >
                    {item.tone === "INFO" ? "변화" : directionLabel(item.tone)}
                  </span>
                  <p className="mt-1.5 text-[11px] font-bold leading-5">
                    {item.text}
                  </p>
                </div>
              </article>
            ))}
            {!feed.length && (
              <p className="rounded-2xl bg-background p-5 text-center text-xs font-bold text-muted-foreground">
                새로운 의미 있는 변화를 기다리는 중입니다.
              </p>
            )}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {[
              "봉 마감",
              "지지·저항 접촉",
              "돌파·이탈",
              "거래량 급증",
              "RSI",
              "MACD",
              "이평 전환",
              "쌍바닥·쌍봉",
              "점수 급변",
              "목표·손절 접근",
            ].map((item) => (
              <span
                key={item}
                className="rounded-full border border-card-border bg-secondary px-2 py-1 text-[9px] font-black text-muted-foreground"
              >
                {item}
              </span>
            ))}
          </div>
        </CollapsibleSectionCard>

        </div>

        <section ref={autoSectionRef} className={cn("scroll-mt-4", viewMode !== "auto" && "hidden")}>
          <CollapsibleSectionCard
            title="선물 자동매매"
            subtitle="모의매매·실주문·긴급정지·주문별 최종 승인"
            open={openSections.auto}
            onToggle={() => toggleSection("auto")}
          >
            <div
              className={cn(
                "rounded-2xl border p-3",
                killSwitchEnabled
                  ? "border-destructive/30 bg-destructive/10"
                  : "border-positive/30 bg-positive/10",
              )}
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-black">
                    {killSwitchEnabled ? "긴급정지 켜짐" : "긴급정지 해제"}
                  </p>
                  <p className="mt-1 text-[10px] font-bold text-muted-foreground">
                    {String(
                      autoStatus.data?.killSwitchReason ??
                        "서버 안전상태 확인 중",
                    )}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void updateKillSwitch(!killSwitchEnabled)}
                  disabled={pendingAction === "kill"}
                  className={cn(
                    "rounded-xl px-3 py-2 text-[10px] font-black",
                    killSwitchEnabled
                      ? "bg-positive text-white"
                      : "bg-destructive text-white",
                  )}
                >
                  {pendingAction === "kill"
                    ? "처리 중"
                    : killSwitchEnabled
                      ? "안전정지 해제"
                      : "긴급정지"}
                </button>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <SelectField
                label="실행 모드"
                value={settings.executionMode}
                onChange={(value) =>
                  changeExecutionMode(value as ExecutionMode)
                }
                options={[
                  { value: "PAPER", label: "모의매매" },
                  { value: "REAL", label: "실주문" },
                ]}
              />
              <SelectField
                label="포지션 모드"
                value={settings.positionMode}
                onChange={(value) =>
                  updateSettings({ positionMode: value as PositionMode })
                }
                options={[
                  { value: "one_way_mode", label: "단방향" },
                  { value: "hedge_mode", label: "헤지" },
                ]}
              />
              <SelectField
                label="마진 모드"
                value={settings.marginMode}
                onChange={(value) =>
                  updateSettings({ marginMode: value as MarginMode })
                }
                options={[
                  { value: "isolated", label: "격리" },
                  { value: "crossed", label: "교차" },
                ]}
              />
              <NumberField
                label="레버리지"
                value={settings.leverage}
                min={1}
                max={125}
                step={1}
                placeholder="예: 2"
                onChange={(value) => updateSettings({ leverage: value })}
              />
              <NumberField
                label="1회 증거금"
                value={settings.marginAmountUSDT}
                min={1}
                max={100000}
                step={0.1}
                placeholder="예: 20"
                onChange={(value) =>
                  updateSettings({ marginAmountUSDT: value })
                }
              />
              <NumberField
                label="최소 신호점수"
                value={settings.minScore}
                min={50}
                max={100}
                step={1}
                placeholder="예: 75"
                onChange={(value) => updateSettings({ minScore: value })}
              />
              <NumberField
                label="손절률"
                value={settings.stopLossPercent}
                min={0.1}
                max={50}
                step={0.1}
                placeholder="예: 0.5"
                onChange={(value) => updateSettings({ stopLossPercent: value })}
              />
              <NumberField
                label="목표 수익률"
                value={settings.targetProfitPercent}
                min={0.1}
                max={100}
                step={0.1}
                placeholder="예: 2.5"
                onChange={(value) =>
                  updateSettings({ targetProfitPercent: value })
                }
              />
              <NumberField
                label="최대 동시보유"
                value={settings.maxOpenPositions}
                min={1}
                max={20}
                step={1}
                placeholder="예: 3"
                onChange={(value) =>
                  updateSettings({ maxOpenPositions: value })
                }
              />
              <NumberField
                label="하루 신규주문"
                value={settings.maxDailyOrders}
                min={1}
                max={100}
                step={1}
                placeholder="예: 5"
                onChange={(value) => updateSettings({ maxDailyOrders: value })}
              />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => void buildConfigurePlan()}
                className="rounded-2xl border border-card-border bg-background p-3 text-xs font-black"
              >
                거래소 설정계획
              </button>
              <button
                type="button"
                onClick={() =>
                  currentAnalysis?.direction === "WAIT"
                    ? setPlanMenuOpen((current) => !current)
                    : void buildOpenPlan()
                }
                className="rounded-2xl bg-primary p-3 text-xs font-black text-primary-foreground"
              >
                {currentAnalysis?.direction === "WAIT"
                  ? "관망 준비계획서"
                  : `${directionLabel(currentAnalysis?.direction ?? "WAIT")} 주문계획`}
              </button>
            </div>
            {planMenuOpen && (
              <div className="mt-2 grid grid-cols-2 gap-2 rounded-2xl border border-card-border bg-background p-2">
                <button
                  type="button"
                  onClick={createWatchPlan}
                  className="rounded-xl bg-primary p-2 text-xs font-black text-primary-foreground"
                >
                  만들기
                </button>
                <button
                  type="button"
                  onClick={openPlanViewer}
                  className="rounded-xl bg-secondary p-2 text-xs font-black"
                >
                  보기
                </button>
              </div>
            )}
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Metric
                label="실제 사용가능"
                value={
                  availableUSDT == null
                    ? "조회 중"
                    : `${formatPrice(availableUSDT)} USDT`
                }
              />
              <Metric
                label="계좌 평가"
                value={
                  accountEquityUSDT == null
                    ? "조회 중"
                    : `${formatPrice(accountEquityUSDT)} USDT`
                }
              />
              <Metric
                label="미실현 손익"
                value={
                  unrealizedPLUSDT == null
                    ? "조회 중"
                    : `${formatPrice(unrealizedPLUSDT)} USDT`
                }
              />
              <Metric
                label="거래소 모드"
                value={`${exchangePositionMode} · ${exchangeMarginMode}`}
              />
            </div>
            {message && (
              <p className="mt-3 rounded-2xl bg-secondary p-3 text-[11px] font-bold leading-5">
                {message}
              </p>
            )}
          </CollapsibleSectionCard>
        </section>

        <CollapsibleSectionCard
          title="실제 보유 포지션"
          subtitle={`${positions.length}개 · 비트겟 실제 계좌 기준`}
          open={openSections.positions}
          onToggle={() => toggleSection("positions")}
        >
          <div className="space-y-2">
            {positions.map((position) => (
              <div
                key={`${position.symbol}:${position.holdSide}`}
                className="rounded-2xl border border-card-border bg-background p-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-black">
                      {position.symbol} · {position.holdSide}
                    </p>
                    <p className="mt-1 text-[10px] font-bold text-muted-foreground">
                      수량 {formatPrice(position.total)} · 진입{" "}
                      {formatPrice(position.openPriceAvg)} · {position.leverage}
                      배
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void buildClosePlan(position)}
                    className="rounded-xl bg-destructive px-3 py-2 text-[10px] font-black text-white"
                  >
                    종료계획
                  </button>
                </div>
                <p
                  className={cn(
                    "mt-2 text-xs font-black",
                    position.unrealizedPL >= 0
                      ? "text-positive"
                      : "text-destructive",
                  )}
                >
                  미실현 {formatPrice(position.unrealizedPL)} USDT
                </p>
              </div>
            ))}
            {!positions.length && (
              <p className="rounded-2xl bg-background p-5 text-center text-xs font-bold text-muted-foreground">
                현재 보유 포지션이 없습니다.
              </p>
            )}
          </div>
        </CollapsibleSectionCard>

        <CollapsibleSectionCard
          title="자동매매 기록"
          subtitle="모의매매·실주문·설정·청산 기록"
          open={openSections.journal}
          onToggle={() => toggleSection("journal")}
        >
          <div className="space-y-2">
            {((autoStatus.data?.latestJournal ?? []) as AnyObj[]).map(
              (entry, index) => (
                <div
                  key={String(entry.id ?? index)}
                  className="rounded-2xl border border-card-border bg-background p-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-black">
                      {String(entry.symbol ?? entry.kind ?? "기록")}
                    </p>
                    <span className="text-[9px] font-bold text-muted-foreground">
                      {entry.createdAt
                        ? new Date(entry.createdAt).toLocaleString("ko-KR")
                        : ""}
                    </span>
                  </div>
                  <p className="mt-1 text-[10px] font-bold leading-5 text-muted-foreground">
                    {String(entry.message ?? entry.status ?? "-")}
                  </p>
                </div>
              ),
            )}
            {!((autoStatus.data?.latestJournal ?? []) as AnyObj[]).length && (
              <p className="rounded-2xl bg-background p-5 text-center text-xs font-bold text-muted-foreground">
                아직 자동매매 기록이 없습니다.
              </p>
            )}
          </div>
        </CollapsibleSectionCard>

        <CollapsibleSectionCard
          title="비트겟 연결상태·실행키"
          subtitle="실행키는 Enter로 서버 확인 · 눈 버튼으로 보기/숨기기"
          open={openSections.status}
          onToggle={() => toggleSection("status")}
        >
          <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-black">
            <StatusPill
              ok={serverConnected}
              label={`BITGET 시세 · ${serverConnected ? "정상" : "오류"}`}
            />
            <StatusPill
              ok={privateConfigured}
              label={`개인 API · ${privateConfigured ? "설정" : "미설정"}`}
            />
            <StatusPill
              ok={Boolean(autoStatus.data?.serverTradingEnabled)}
              label={`서버 실주문 · ${autoStatus.data?.serverTradingEnabled ? "켜짐" : "꺼짐"}`}
            />
            <StatusPill
              ok={Boolean(autoStatus.data?.executionKeyConfigured)}
              label={`보호키 · ${autoStatus.data?.executionKeyConfigured ? "설정" : "미설정"}`}
            />
            <StatusPill
              ok={!killSwitchEnabled}
              label={`긴급정지 · ${killSwitchEnabled ? "켜짐" : "해제"}`}
            />
            <StatusPill
              ok={!autoStatus.data?.lastSyncError}
              label={`동기화 · ${autoStatus.data?.lastSyncError ? "오류" : "정상"}`}
            />
          </div>
          <div className="mt-3 rounded-2xl border border-card-border bg-background p-3">
            <div className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-primary" />
              <p className="text-[10px] font-black">자동매매 실행키</p>
            </div>
            <div className="relative mt-2">
              <input
                type={showExecutionKey ? "text" : "password"}
                value={executionKey}
                onChange={(event) => {
                  setExecutionKey(event.target.value);
                  setExecutionKeySaved(false);
                  setPendingPlan(null);
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    void registerExecutionKey();
                  }
                }}
                placeholder="CRYPTO_AUTO_TRADE_KEY 입력 후 Enter"
                autoComplete="off"
                className="h-11 w-full rounded-xl border border-card-border bg-card px-3 pr-12 text-sm font-bold outline-none focus:border-primary"
              />
              <button
                type="button"
                onClick={() => setShowExecutionKey((current) => !current)}
                className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground"
              >
                {showExecutionKey ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>
            <div className="mt-2 flex items-center justify-between">
              <span
                className={cn(
                  "text-[10px] font-black",
                  executionKeySaved ? "text-positive" : "text-muted-foreground",
                )}
              >
                {keyVerifying
                  ? "서버 확인 중..."
                  : executionKeySaved
                    ? "✓ 서버 확인 완료"
                    : "Enter를 눌러 확인"}
              </span>
              <button
                type="button"
                onClick={() => void registerExecutionKey()}
                disabled={keyVerifying}
                className="rounded-full bg-primary px-3 py-1.5 text-[10px] font-black text-primary-foreground disabled:opacity-50"
              >
                {keyVerifying ? "확인 중" : "확인"}
              </button>
            </div>
          </div>
        </CollapsibleSectionCard>
      </main>

      {signalCandidate && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-5 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setSignalCandidate(null);
          }}
        >
          <div className="max-h-[82vh] w-full max-w-sm overflow-y-auto rounded-3xl border border-card-border bg-card p-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-black text-primary">신호검색기 분석</p>
                <h2 className="mt-1 text-base font-black">{signalCandidate.ticker.symbol}</h2>
              </div>
              <button type="button" onClick={() => setSignalCandidate(null)} className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary" aria-label="닫기">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 rounded-2xl bg-secondary/70 p-3 text-left text-xs font-bold leading-5 text-muted-foreground">
              <p className="font-black text-foreground">{directionLabel(signalCandidate.analysis.direction)} 의견 이유</p>
              <p className="mt-2">{signalCandidate.analysis.direction === "SHORT" ? signalCandidate.analysis.shortReasons.slice(0, 4).join(" · ") : signalCandidate.analysis.direction === "LONG" ? signalCandidate.analysis.longReasons.slice(0, 4).join(" · ") : [...signalCandidate.analysis.longReasons, ...signalCandidate.analysis.shortReasons].slice(0, 4).join(" · ") || "롱·숏 조건이 비슷해 관망 신호입니다."}</p>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <Metric label="롱 점수" value={`${signalCandidate.analysis.longScore}점`} />
              <Metric label="숏 점수" value={`${signalCandidate.analysis.shortScore}점`} />
              <Metric label="종합신호" value={directionLabel(signalCandidate.analysis.direction)} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Metric label="롱 목표/손절" value={`${formatPrice(signalCandidate.analysis.targetLong)} / ${formatPrice(signalCandidate.analysis.stopLong)}`} />
              <Metric label="숏 목표/손절" value={`${formatPrice(signalCandidate.analysis.targetShort)} / ${formatPrice(signalCandidate.analysis.stopShort)}`} />
            </div>
            <button
              type="button"
              onClick={() => {
                const next = signalCandidate.ticker.symbol;
                setSignalCandidate(null);
                onViewModeChange("chart");
                selectSymbol(next);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="mt-4 w-full rounded-2xl bg-primary px-4 py-3 text-sm font-black text-primary-foreground"
            >
              {signalCandidate.ticker.symbol}으로 이동
            </button>
            <button type="button" onClick={() => setSignalCandidate(null)} className="mt-2 w-full rounded-2xl bg-secondary px-4 py-3 text-sm font-black">닫기</button>
          </div>
        </div>
      )}

      {scoreModal && currentAnalysis && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-5 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setScoreModal(null);
          }}
        >
          <div className="max-h-[82vh] w-full max-w-sm overflow-y-auto rounded-3xl border border-card-border bg-card p-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-black text-primary">
                  점수 상세분석
                </p>
                <h2 className="mt-1 text-base font-black">
                  {scoreModal === "LONG"
                    ? `롱 점수 ${currentAnalysis.longScore}점`
                    : scoreModal === "SHORT"
                      ? `숏 점수 ${currentAnalysis.shortScore}점`
                      : `종합신호 ${directionLabel(currentAnalysis.direction)}`}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setScoreModal(null)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <ScoreReasonList analysis={currentAnalysis} kind={scoreModal} />
            <div className="mt-3 space-y-2">
              <PerspectiveCard
                label="단타 관점 · 15분봉"
                analysis={perspectiveQuery.data?.["15m"] ?? null}
              />
              <PerspectiveCard
                label="스윙 관점 · 4시간봉"
                analysis={perspectiveQuery.data?.["4H"] ?? null}
              />
              <PerspectiveCard
                label="중장기 관점 · 일봉"
                analysis={perspectiveQuery.data?.["1D"] ?? null}
              />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Metric
                label="진입 확인"
                value={
                  currentAnalysis.direction === "SHORT"
                    ? `지지 ${formatPrice(currentAnalysis.support1)} 이탈`
                    : `저항 ${formatPrice(currentAnalysis.resistance1)} 돌파`
                }
              />
              <Metric
                label="무효화"
                value={
                  currentAnalysis.direction === "SHORT"
                    ? `저항 ${formatPrice(currentAnalysis.resistance1)} 회복`
                    : `지지 ${formatPrice(currentAnalysis.support1)} 이탈`
                }
              />
              <Metric
                label="롱 목표/손절"
                value={`${formatPrice(currentAnalysis.targetLong)} / ${formatPrice(currentAnalysis.stopLong)}`}
              />
              <Metric
                label="숏 목표/손절"
                value={`${formatPrice(currentAnalysis.targetShort)} / ${formatPrice(currentAnalysis.stopShort)}`}
              />
            </div>
          </div>
        </div>
      )}

      {alertEditorSymbol && (
        <AlertEditorModal
          symbol={alertEditorSymbol}
          rule={currentAlertRule}
          onClose={() => setAlertEditorSymbol(null)}
          onSave={saveAlertRule}
        />
      )}

      {planViewerOpen && (pendingPlan || watchPlan) && (
        <PlanViewerModal
          planKind={planKind}
          pendingPlan={pendingPlan}
          watchPlan={watchPlan}
          pendingAction={pendingAction}
          onClose={() => setPlanViewerOpen(false)}
          onApprove={() =>
            void (planKind === "OPEN"
              ? approveOpen()
              : planKind === "CLOSE"
                ? approveClose()
                : approveConfigure())
          }
        />
      )}

      <BottomNav />
    </div>
  );
}

function TopTab({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-xl border px-3 py-2 text-xs font-black",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-card-border bg-card text-muted-foreground",
      )}
    >
      {children}
    </button>
  );
}

function CollapsibleSectionCard({
  title,
  subtitle,
  open,
  onToggle,
  children,
}: {
  title: string;
  subtitle?: string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  return (
    <section className="rounded-3xl border border-card-border bg-card shadow-sm">
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-3 p-4 text-left"
      >
        <h2 className="flex-1 text-center text-sm font-black">{title}</h2>
        {open ? (
          <ChevronUp className="h-4 w-4 shrink-0" />
        ) : (
          <ChevronDown className="h-4 w-4 shrink-0" />
        )}
      </button>
      {open && (
        <div className="border-t border-card-border p-4">{children}</div>
      )}
    </section>
  );
}

function SortHeader({
  label,
  active,
  direction,
  onClick,
}: {
  label: string;
  active: boolean;
  direction: SortDirection;
  onClick: () => void;
}) {
  const Icon =
    direction === "desc"
      ? ArrowDown
      : direction === "asc"
        ? ArrowUp
        : ArrowUpDown;
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center justify-end gap-1 text-[10px] font-black",
        active ? "text-primary" : "text-muted-foreground",
      )}
    >
      <span>{label}</span>
      <Icon className="h-3.5 w-3.5" />
    </button>
  );
}

function formatCompact(value: number) {
  if (!Number.isFinite(value)) return "-";
  return new Intl.NumberFormat("ko-KR", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}

function StatusPill({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span
      className={cn(
        "rounded-xl border px-2 py-2",
        ok
          ? "border-positive/30 bg-positive/10 text-positive"
          : "border-destructive/30 bg-destructive/10 text-destructive",
      )}
    >
      {label}
    </span>
  );
}

function ScoreButton({
  label,
  value,
  tone,
  active,
  onClick,
}: {
  label: string;
  value: string;
  tone: "long" | "short" | "total";
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-2xl border p-2.5 text-center",
        tone === "long"
          ? "border-positive/30 bg-positive/10"
          : tone === "short"
            ? "border-destructive/30 bg-destructive/10"
            : "border-primary/30 bg-primary/10",
        active && "ring-1 ring-current",
      )}
    >
      <p className="text-[9px] font-black text-muted-foreground">{label}</p>
      <p
        className={cn(
          "mt-1 text-sm font-black",
          tone === "long"
            ? "text-positive"
            : tone === "short"
              ? "text-destructive"
              : "text-primary",
        )}
      >
        {value}
      </p>
      <p className="mt-1 text-[8px] font-bold text-muted-foreground">
        눌러서 근거 보기
      </p>
    </button>
  );
}

function ScoreReasonList({
  analysis,
  kind,
}: {
  analysis: Analysis;
  kind: Exclude<ScoreModalKind, null>;
}) {
  const reasons =
    kind === "SHORT"
      ? analysis.shortReasons
      : kind === "LONG"
        ? analysis.longReasons
        : [
            ...analysis.longReasons.slice(0, 3),
            ...analysis.shortReasons.slice(0, 3),
          ];
  return (
    <div className="mt-3 rounded-2xl bg-secondary p-3">
      <p className="text-[10px] font-black">점수에 반영된 핵심 조건</p>
      <div className="mt-2 space-y-1">
        {reasons.map((reason, index) => (
          <p
            key={`${reason}:${index}`}
            className="text-[10px] font-bold leading-5 text-muted-foreground"
          >
            · {reason}
          </p>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <Metric
          label="추세"
          value={
            analysis.sma5 != null && analysis.sma20 != null
              ? analysis.sma5 >= analysis.sma20
                ? "상승"
                : "하락"
              : "-"
          }
        />
        <Metric label="RSI" value={analysis.rsi?.toFixed(1) ?? "-"} />
        <Metric label="거래량" value={`${analysis.volumeRatio.toFixed(1)}배`} />
      </div>
    </div>
  );
}

function PerspectiveCard({
  label,
  analysis,
}: {
  label: string;
  analysis: Analysis | null;
}) {
  return (
    <div className="rounded-2xl border border-card-border bg-background p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] font-black">{label}</p>
        {analysis && (
          <span
            className={cn(
              "rounded-full border px-2 py-0.5 text-[9px] font-black",
              toneClass(analysis.direction),
            )}
          >
            {directionLabel(analysis.direction)}
          </span>
        )}
      </div>
      {analysis ? (
        <>
          <p className="mt-2 text-[10px] font-bold leading-5 text-muted-foreground">
            롱 {analysis.longScore} · 숏 {analysis.shortScore} ·{" "}
            {analysis.direction === "LONG"
              ? analysis.longReasons[0]
              : analysis.direction === "SHORT"
                ? analysis.shortReasons[0]
                : "상하위 봉 방향 확인 전 관망"}
          </p>
          <p className="mt-1 text-[9px] font-bold text-muted-foreground">
            지지 {formatPrice(analysis.support1)} · 저항{" "}
            {formatPrice(analysis.resistance1)}
          </p>
        </>
      ) : (
        <p className="mt-2 text-[10px] font-bold text-muted-foreground">
          분석 데이터 불러오는 중
        </p>
      )}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-card-border bg-background p-2.5">
      <p className="text-[9px] font-black text-muted-foreground">{label}</p>
      <p className="mt-1 break-words text-[10px] font-black">{value}</p>
    </div>
  );
}

function LoadingBox({ text }: { text: string }) {
  return (
    <div className="flex min-h-28 items-center justify-center gap-2 p-5 text-xs font-bold text-muted-foreground">
      <Loader2 className="h-4 w-4 animate-spin" />
      {text}
    </div>
  );
}

function ErrorBox({ text }: { text: string }) {
  return (
    <div className="flex min-h-28 flex-col items-center justify-center p-5 text-center">
      <ShieldAlert className="h-6 w-6 text-warning" />
      <p className="mt-2 text-xs font-bold text-warning">{text}</p>
    </div>
  );
}

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange: (value: string) => void;
}) {
  return (
    <label className="rounded-2xl border border-card-border bg-background p-3">
      <span className="text-[9px] font-black text-muted-foreground">
        {label}
      </span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 h-9 w-full bg-transparent text-xs font-black outline-none"
      >
        {options.map((item) => (
          <option key={item.value} value={item.value}>
            {item.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function NumberField({
  label,
  value,
  min,
  max,
  step,
  placeholder,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  placeholder: string;
  onChange: (value: number) => void;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (Number.isFinite(value) && text !== "" && Number(text) !== value)
      setText(String(value));
  }, [value]);
  const commit = () => {
    if (!text.trim()) {
      onChange(Number.NaN);
      return;
    }
    const parsed = Number(text);
    if (!Number.isFinite(parsed)) return;
    if (parsed < min || parsed > max) return;
    onChange(parsed);
  };
  return (
    <label className="rounded-2xl border border-card-border bg-background p-3">
      <span className="text-[9px] font-black text-muted-foreground">
        {label}
      </span>
      <input
        type="text"
        inputMode="decimal"
        value={text}
        placeholder={placeholder}
        onFocus={(event) => event.currentTarget.select()}
        onChange={(event) =>
          setText(event.target.value.replace(/[^0-9.-]/g, ""))
        }
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            commit();
            event.currentTarget.blur();
          }
        }}
        className="mt-1 h-9 w-full bg-transparent text-xs font-black outline-none placeholder:text-muted-foreground/60"
      />
      <span className="mt-1 block text-[8px] font-bold text-muted-foreground">
        허용 {min}~{max} · 빈칸에서 바로 입력
      </span>
    </label>
  );
}

function AlertEditorModal({
  symbol,
  rule,
  onClose,
  onSave,
}: {
  symbol: string;
  rule: AssetAlertRule;
  onClose: () => void;
  onSave: (rule: AssetAlertRule) => void;
}) {
  const [draft, setDraft] = useState<AssetAlertRule>(rule);
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-5 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.currentTarget === event.target) onClose();
      }}
    >
      <div className="w-full max-w-sm rounded-3xl border border-card-border bg-card p-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black text-primary">알림 설정</p>
            <h2 className="mt-1 text-base font-black">{symbol}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-3 space-y-3">
          <AlertCheck
            label="목표가격 알림"
            checked={draft.targetEnabled}
            onChange={(checked) =>
              setDraft({ ...draft, targetEnabled: checked })
            }
          >
            <div className="mt-2 grid grid-cols-[110px_1fr] gap-2">
              <select
                value={draft.targetDirection}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    targetDirection: event.target.value as "above" | "below",
                  })
                }
                className="rounded-xl border border-card-border bg-background px-2 text-xs font-bold"
              >
                <option value="above">이상 도달</option>
                <option value="below">이하 도달</option>
              </select>
              <input
                value={draft.targetPrice}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    targetPrice: event.target.value.replace(/[^0-9.]/g, ""),
                  })
                }
                inputMode="decimal"
                placeholder="원하는 가격"
                className="h-10 rounded-xl border border-card-border bg-background px-3 text-xs font-bold outline-none"
              />
            </div>
          </AlertCheck>
          <AlertCheck
            label="등락률 알림"
            checked={draft.changeEnabled}
            onChange={(checked) =>
              setDraft({ ...draft, changeEnabled: checked })
            }
          >
            <div className="mt-2 grid grid-cols-[110px_1fr] gap-2">
              <select
                value={draft.changeDirection}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    changeDirection: event.target.value as "up" | "down",
                  })
                }
                className="rounded-xl border border-card-border bg-background px-2 text-xs font-bold"
              >
                <option value="up">상승</option>
                <option value="down">하락</option>
              </select>
              <input
                value={draft.changePercent}
                onChange={(event) =>
                  setDraft({
                    ...draft,
                    changePercent: event.target.value.replace(/[^0-9.]/g, ""),
                  })
                }
                inputMode="decimal"
                placeholder="등락률 %"
                className="h-10 rounded-xl border border-card-border bg-background px-3 text-xs font-bold outline-none"
              />
            </div>
          </AlertCheck>
          <AlertCheck
            label="뉴스·거래소 공지 알림"
            checked={draft.newsEnabled}
            onChange={(checked) => setDraft({ ...draft, newsEnabled: checked })}
          >
            <p className="mt-1 text-[9px] font-bold text-muted-foreground">
              뉴스·거래소 공지 수집 연결 시 이 설정을 사용합니다.
            </p>
          </AlertCheck>
        </div>
        <button
          type="button"
          onClick={async () => {
            if (
              typeof Notification !== "undefined" &&
              Notification.permission === "default"
            )
              await Notification.requestPermission();
            onSave(draft);
          }}
          className="mt-4 w-full rounded-2xl bg-primary py-3 text-xs font-black text-primary-foreground"
        >
          알림 저장
        </button>
      </div>
    </div>
  );
}

function AlertCheck({
  label,
  checked,
  onChange,
  children,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  children: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-card-border bg-background p-3">
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={checked}
          onChange={(event) => onChange(event.target.checked)}
        />
        <span className="text-xs font-black">{label}</span>
      </label>
      {children}
    </div>
  );
}

function PlanViewerModal({
  planKind,
  pendingPlan,
  watchPlan,
  pendingAction,
  onClose,
  onApprove,
}: {
  planKind: string;
  pendingPlan: PlanResponse | null;
  watchPlan: WatchPlan | null;
  pendingAction: string | null;
  onClose: () => void;
  onApprove: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-5 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.currentTarget === event.target) onClose();
      }}
    >
      <div className="max-h-[78vh] w-full max-w-sm overflow-y-auto rounded-3xl border border-card-border bg-card p-4 shadow-2xl">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[10px] font-black text-primary">계획서 보기</p>
            <h2 className="mt-1 text-base font-black">
              {planKind === "WATCH"
                ? "관망 준비계획서"
                : planKind === "CONFIGURE"
                  ? "거래소 설정계획"
                  : planKind === "CLOSE"
                    ? "포지션 종료계획"
                    : "롱·숏 주문계획"}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        {planKind === "WATCH" && watchPlan && (
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Metric
              label="종목·기준봉"
              value={`${watchPlan.symbol} · ${timeframeLabel(watchPlan.timeframe)}`}
            />
            <Metric
              label="롱·숏 점수"
              value={`${watchPlan.longScore} / ${watchPlan.shortScore}`}
            />
            <Metric
              label="롱 준비선"
              value={formatPrice(watchPlan.resistanceTrigger)}
            />
            <Metric
              label="숏 준비선"
              value={formatPrice(watchPlan.supportTrigger)}
            />
          </div>
        )}
        {pendingPlan && (
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Metric
              label="종류"
              value={String(pendingPlan.plan?.kind ?? planKind)}
            />
            <Metric
              label="종목"
              value={String(pendingPlan.plan?.symbol ?? "-")}
            />
            <Metric
              label="방향·모드"
              value={`${String(pendingPlan.plan?.direction ?? "-")} · ${String(pendingPlan.plan?.executionMode ?? "-")}`}
            />
            <Metric
              label="수량"
              value={String(
                pendingPlan.plan?.sizeText ??
                  pendingPlan.plan?.positionSize ??
                  "-",
              )}
            />
            <Metric
              label="손절가"
              value={formatPrice(numberOf(pendingPlan.plan?.stopPrice))}
            />
            <Metric
              label="목표가"
              value={formatPrice(numberOf(pendingPlan.plan?.targetPrice))}
            />
          </div>
        )}
        {pendingPlan?.warning && (
          <p className="mt-3 rounded-2xl bg-warning/10 p-3 text-[10px] font-bold text-warning">
            {pendingPlan.warning}
          </p>
        )}
        {planKind !== "WATCH" && pendingPlan && (
          <button
            type="button"
            onClick={onApprove}
            disabled={pendingAction != null}
            className="mt-3 w-full rounded-2xl bg-destructive py-3 text-xs font-black text-white disabled:opacity-50"
          >
            {pendingAction ? "처리 중..." : "최종 승인"}
          </button>
        )}
      </div>
    </div>
  );
}