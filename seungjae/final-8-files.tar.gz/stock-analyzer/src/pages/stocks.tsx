import { useMemo, useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronRight } from 'lucide-react';
import { BottomNav } from '@/components/bottom-nav';
import { AssetSwitch } from '@/components/asset-switch';
import { AppModal } from '@/components/app-modal';
import { SearchField } from '@/components/search-field';
import { ErrorState, LoadingState } from '@/components/data-state';
import { api, apiGet, type QuoteRow } from '@/lib/api';
import { useAssetMode } from '@/lib/asset-mode';
import { displayCoinName, displayStockName, formatAppPercent, formatAppPrice } from '@/lib/stock-display';
import { cn } from '@/lib/utils';

type AnyObj = Record<string, any>;
type CategoryKey = 'marketCap' | 'volume' | 'tradingValue' | 'gainers' | 'losers' | 'ai';
type SortDirection = 'default' | 'asc' | 'desc';
type AiGroup = 'undervalued' | 'bottom' | 'accumulation' | 'breakout';

const CATEGORIES: { key: CategoryKey; label: string }[] = [
  { key: 'marketCap', label: '시가총액' },
  { key: 'volume', label: '거래량' },
  { key: 'tradingValue', label: '거래대금' },
  { key: 'gainers', label: '급상승' },
  { key: 'losers', label: '급하락' },
  { key: 'ai', label: 'AI추천' },
];

const AI_GROUPS: { key: AiGroup; label: string }[] = [
  { key: 'undervalued', label: '저평가' },
  { key: 'bottom', label: '바닥권' },
  { key: 'accumulation', label: '매집' },
  { key: 'breakout', label: '추세돌파' },
];

interface RecoRow {
  ticker: string;
  name: string;
  market: 'KR' | 'US';
  currency: 'KRW' | 'USD';
  category: string;
  categoryLabel?: string;
  price: number;
  changePercent: number;
  reasons: string[];
  risks?: string[];
  score: number;
  entry?: number;
  target?: number;
  stop?: number;
}

interface RecoResponse {
  market: 'KR' | 'US';
  rows: RecoRow[];
}

interface CandidateDetail {
  kind: 'stock' | 'coin';
  name: string;
  symbol: string;
  marketLabel: string;
  opinion: string;
  score: number | null;
  reasons: string[];
  risks: string[];
  price: number | null;
  changePercent: number | null;
  target?: number | null;
  stop?: number | null;
  moveTo: string;
}

function finite(value: unknown): number | null {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function nextSort(value: SortDirection): SortDirection {
  return value === 'default' ? 'asc' : value === 'asc' ? 'desc' : 'default';
}

export default function StocksPage() {
  const [, navigate] = useLocation();
  const mode = useAssetMode();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CategoryKey | null>(null);
  const [aiGroup, setAiGroup] = useState<AiGroup>('undervalued');
  const [nameSort, setNameSort] = useState<SortDirection>('default');
  const [metricSort, setMetricSort] = useState<SortDirection>('default');
  const [candidate, setCandidate] = useState<CandidateDetail | null>(null);
  const trimmed = query.trim();
  const searching = trimmed.length > 0;
  const isStock = mode.asset === 'stock';

  const stockRows = useQuery({
    queryKey: ['stocks-directory', mode.stockMarket, trimmed],
    queryFn: () => api.searchRows(trimmed),
    enabled: isStock && searching,
    staleTime: 15_000,
  });
  const recommendations = useQuery({
    queryKey: ['stocks-recommendations', mode.stockMarket],
    queryFn: () => apiGet<RecoResponse>(`/market/recommendations?market=${mode.stockMarket}`),
    enabled: isStock,
    staleTime: 30_000,
  });
  const movers = useQuery({
    queryKey: ['stocks-movers', mode.stockMarket],
    queryFn: () => apiGet<AnyObj>(`/market/movers?market=${mode.stockMarket}`),
    enabled: isStock,
    staleTime: 15_000,
    refetchInterval: 30_000,
  });
  const spotMarkets = useQuery({
    queryKey: ['stocks-crypto-spot-markets'],
    queryFn: () => apiGet<AnyObj>('/crypto/spot/markets'),
    enabled: !isStock && mode.coinMarket === 'spot',
    staleTime: 10 * 60_000,
  });
  const spotTickers = useQuery({
    queryKey: ['stocks-crypto-spot-tickers'],
    queryFn: () => apiGet<AnyObj>('/crypto/spot/tickers'),
    enabled: !isStock && mode.coinMarket === 'spot',
    refetchInterval: 15_000,
  });
  const futuresTickers = useQuery({
    queryKey: ['stocks-crypto-futures-tickers'],
    queryFn: () => apiGet<AnyObj>('/crypto/futures/tickers'),
    enabled: !isStock && mode.coinMarket === 'futures',
    refetchInterval: 10_000,
  });

  const spotNames = useMemo(() => new Map<string, AnyObj>(((spotMarkets.data?.markets ?? []) as AnyObj[]).map((row) => [String(row.symbol), row])), [spotMarkets.data]);
  const coinRows = useMemo<AnyObj[]>(() => {
    if (isStock) return [];
    return mode.coinMarket === 'spot'
      ? ((spotTickers.data?.tickers ?? []) as AnyObj[]).map((row) => ({ ...row, ...(spotNames.get(String(row.symbol)) ?? {}) }))
      : ((futuresTickers.data?.tickers ?? []) as AnyObj[]);
  }, [futuresTickers.data, isStock, mode.coinMarket, spotNames, spotTickers.data]);

  const stockSearchResults = useMemo(() => {
    const rows = (stockRows.data?.results ?? []) as QuoteRow[];
    return rows.filter((row) => row.market === mode.stockMarket).slice(0, 30);
  }, [mode.stockMarket, stockRows.data]);
  const coinSearchResults = useMemo(() => {
    if (!searching) return [];
    const needle = trimmed.toLowerCase();
    return coinRows.filter((row) => [row.symbol, row.koreanName, row.englishName, displayCoinName(String(row.symbol), row.koreanName, row.englishName)].some((value) => String(value ?? '').toLowerCase().includes(needle))).slice(0, 30);
  }, [coinRows, searching, trimmed]);

  const stockCategoryRows = useMemo<AnyObj[]>(() => {
    if (!category || category === 'ai') return [];
    const source = category === 'volume'
      ? movers.data?.volume
      : category === 'tradingValue'
        ? movers.data?.popular
        : category === 'gainers'
          ? movers.data?.gainers
          : category === 'losers'
            ? movers.data?.losers
            : [...((movers.data?.popular ?? []) as AnyObj[]), ...((movers.data?.volume ?? []) as AnyObj[]), ...((movers.data?.gainers ?? []) as AnyObj[])];
    return dedupe(source ?? [], (row) => `${row.market}:${row.ticker}`).filter((row) => row.market === mode.stockMarket);
  }, [category, mode.stockMarket, movers.data]);

  const coinCategoryRows = useMemo<AnyObj[]>(() => {
    if (!category || category === 'ai') return [];
    const rows = [...coinRows];
    const metric = categoryMetric(category);
    return rows.filter((row) => category !== 'marketCap' || finite(row.marketCap) != null).sort((a, b) => metricValue(b, metric) - metricValue(a, metric));
  }, [category, coinRows]);

  const stockAiRows = useMemo(() => (recommendations.data?.rows ?? []).filter((row) => row.market === mode.stockMarket), [mode.stockMarket, recommendations.data]);
  const coinAiRows = useMemo(() => buildCoinCandidates(coinRows, mode.coinMarket), [coinRows, mode.coinMarket]);

  const modalRows = useMemo(() => {
    const base = category === 'ai'
      ? isStock
        ? stockAiRows.filter((row) => classifyStockAi(row) === aiGroup)
        : coinAiRows.filter((row) => row.aiGroup === aiGroup)
      : isStock ? stockCategoryRows : coinCategoryRows;
    const metric = categoryMetric(category ?? 'tradingValue');
    const rows = [...base];
    if (nameSort !== 'default') rows.sort((a, b) => nameOf(a, isStock).localeCompare(nameOf(b, isStock), isStock ? (mode.stockMarket === 'KR' ? 'ko' : 'en') : 'ko') * (nameSort === 'asc' ? 1 : -1));
    else if (metricSort !== 'default') rows.sort((a, b) => (metricValue(a, metric) - metricValue(b, metric)) * (metricSort === 'asc' ? 1 : -1));
    return rows.slice(0, 100);
  }, [aiGroup, category, coinAiRows, coinCategoryRows, isStock, metricSort, mode.stockMarket, nameSort, stockAiRows, stockCategoryRows]);

  const openCategory = (key: CategoryKey) => {
    setCategory(key);
    setNameSort('default');
    setMetricSort('default');
  };

  const openAiCandidate = (row: AnyObj) => {
    if (isStock) {
      const ticker = String(row.ticker);
      setCandidate({
        kind: 'stock',
        name: displayStockName(ticker, String(row.name ?? ticker), String(row.market)),
        symbol: ticker,
        marketLabel: row.market === 'KR' ? '국내주식' : '해외주식',
        opinion: '매수 후보',
        score: finite(row.score),
        reasons: Array.isArray(row.reasons) ? row.reasons : ['실제 가격·거래량·추세 조건을 종합해 후보로 분류했습니다.'],
        risks: Array.isArray(row.risks) && row.risks.length ? row.risks : ['목표가 도달 전 시장 흐름이 바뀌면 매수 의견이 무효화될 수 있습니다.'],
        price: finite(row.price),
        changePercent: finite(row.changePercent),
        target: finite(row.target),
        stop: finite(row.stop),
        moveTo: `/stock/${encodeURIComponent(ticker)}`,
      });
    } else {
      const symbol = String(row.symbol);
      setCandidate({
        kind: 'coin',
        name: displayCoinName(symbol, row.koreanName, row.englishName),
        symbol,
        marketLabel: mode.coinMarket === 'spot' ? '코인 현물' : '코인 선물',
        opinion: mode.coinMarket === 'futures' ? String(row.opinion ?? '롱 후보') : '매수 후보',
        score: finite(row.score),
        reasons: row.reasons ?? [],
        risks: row.risks ?? ['코인은 변동성이 커서 손절 기준을 반드시 지켜야 합니다.'],
        price: finite(row.price),
        changePercent: finite(row.changePercent ?? row.changePercent24h),
        target: finite(row.target),
        stop: finite(row.stop),
        moveTo: `/stock-info?asset=coin&coinMarket=${mode.coinMarket}&symbol=${encodeURIComponent(symbol)}`,
      });
    }
  };

  const tickerQuery = mode.coinMarket === 'spot' ? spotTickers : futuresTickers;

  return (
    <div className="h-full overflow-y-auto overscroll-contain bg-background">
      <header className="border-b border-card-border px-4 pb-3 pt-4">
        <h1 className="text-center text-xl font-extrabold">종목</h1>
        <AssetSwitch className="mt-3" />
        <div className="mt-3 grid grid-cols-3 gap-2">
          {CATEGORIES.map((item) => (
            <button key={item.key} type="button" onClick={() => openCategory(item.key)} className="rounded-xl border border-card-border bg-card px-2 py-2.5 text-center text-[11px] font-black">{item.label}</button>
          ))}
        </div>
        <SearchField value={query} onChange={setQuery} className="mt-3" ariaLabel={isStock ? '종목 검색' : '코인 검색'} />
      </header>

      <main className="space-y-3 px-4 pb-28 pt-4">
        {!searching && <EmptyBox>{isStock ? '위 분류를 누르거나 종목을 검색하세요.' : '위 분류를 누르거나 코인을 검색하세요.'}</EmptyBox>}
        {searching && isStock && stockRows.isLoading && <LoadingState label="종목을 검색하는 중입니다." />}
        {searching && isStock && stockRows.isError && <ErrorState onRetry={() => void stockRows.refetch()} />}
        {searching && !isStock && tickerQuery.isLoading && <LoadingState label="코인 시세를 불러오는 중입니다." />}
        {searching && !isStock && tickerQuery.isError && <ErrorState onRetry={() => void tickerQuery.refetch()} />}
        {searching && (
          <div className="space-y-2">
            {(isStock ? stockSearchResults : coinSearchResults).map((row) => isStock
              ? <AssetRow key={`${row.market}:${row.ticker}`} row={row} stock onClick={() => navigate(`/stock/${encodeURIComponent(String(row.ticker))}`)} />
              : <AssetRow key={String(row.symbol)} row={row} stock={false} coinMarket={mode.coinMarket} onClick={() => navigate(`/stock-info?asset=coin&coinMarket=${mode.coinMarket}&symbol=${encodeURIComponent(String(row.symbol))}`)} />)}
          </div>
        )}
        {searching && (isStock ? !stockRows.isLoading && stockSearchResults.length === 0 : !tickerQuery.isLoading && coinSearchResults.length === 0) && <EmptyBox>검색 결과가 없습니다.</EmptyBox>}
      </main>
      <BottomNav />

      <AppModal open={Boolean(category)} title={CATEGORIES.find((item) => item.key === category)?.label ?? ''} onClose={() => setCategory(null)}>
        {category === 'ai' && (
          <div className="mb-3 grid grid-cols-4 gap-1.5">
            {AI_GROUPS.map((item) => <button key={item.key} type="button" onClick={() => setAiGroup(item.key)} className={cn('rounded-xl border px-1 py-2 text-[10px] font-black', aiGroup === item.key ? 'border-primary bg-primary text-primary-foreground' : 'border-card-border bg-background')}>{item.label}</button>)}
          </div>
        )}
        <div className="mb-3 grid grid-cols-2 gap-2">
          <SortButton label={isStock ? '주식명' : '코인명'} direction={nameSort} onClick={() => { setNameSort(nextSort(nameSort)); setMetricSort('default'); }} />
          <SortButton label={metricLabel(category ?? 'tradingValue')} direction={metricSort} onClick={() => { setMetricSort(nextSort(metricSort)); setNameSort('default'); }} />
        </div>
        {category === 'ai' && isStock && recommendations.isLoading && <LoadingState label="AI 추천 후보를 계산하는 중입니다." />}
        {category === 'ai' && isStock && recommendations.isError && <ErrorState onRetry={() => void recommendations.refetch()} />}
        {category !== 'ai' && isStock && movers.isLoading && <LoadingState label="실시간 순위 데이터를 불러오는 중입니다." />}
        {category !== 'ai' && isStock && movers.isError && <ErrorState onRetry={() => void movers.refetch()} />}
        {!isStock && tickerQuery.isLoading && <LoadingState label="실시간 코인 데이터를 불러오는 중입니다." />}
        {!isStock && tickerQuery.isError && <ErrorState onRetry={() => void tickerQuery.refetch()} />}
        <div className="space-y-2">
          {modalRows.map((row, index) => (
            <AssetRow
              key={isStock ? `${row.market}:${row.ticker}:${index}` : `${row.symbol}:${index}`}
              row={row}
              stock={isStock}
              coinMarket={mode.coinMarket}
              rank={index + 1}
              category={category ?? undefined}
              onClick={() => {
                if (category === 'ai') openAiCandidate(row);
                else if (isStock) navigate(`/stock/${encodeURIComponent(String(row.ticker))}`);
                else navigate(`/stock-info?asset=coin&coinMarket=${mode.coinMarket}&symbol=${encodeURIComponent(String(row.symbol))}`);
              }}
            />
          ))}
        </div>
        {modalRows.length === 0 && <EmptyBox>{category === 'marketCap' && !isStock ? '현재 거래소 공개 응답에는 코인 시가총액이 없어 표시할 수 없습니다.' : '현재 조건을 충족하는 실제 데이터가 없습니다.'}</EmptyBox>}
      </AppModal>

      <AppModal
        open={Boolean(candidate)}
        title={candidate ? `${candidate.name} 분석` : ''}
        onClose={() => setCandidate(null)}
        footer={candidate ? <div className="grid grid-cols-2 gap-2"><button type="button" onClick={() => setCandidate(null)} className="rounded-2xl border border-card-border bg-secondary px-3 py-3 text-sm font-black">닫기</button><button type="button" onClick={() => navigate(candidate.moveTo)} className="rounded-2xl bg-primary px-3 py-3 text-sm font-black text-primary-foreground">{candidate.name}으로 이동</button></div> : undefined}
      >
        {candidate && <CandidateContent candidate={candidate} />}
      </AppModal>
    </div>
  );
}

function CandidateContent({ candidate }: { candidate: CandidateDetail }) {
  return <div className="space-y-3">
    <div className="grid grid-cols-2 gap-2"><Metric label="종합의견" value={candidate.opinion} /><Metric label="AI 점수" value={candidate.score == null ? '데이터 없음' : `${candidate.score}점`} /></div>
    <div className="grid grid-cols-2 gap-2"><Metric label="현재가" value={candidate.price == null ? '데이터 없음' : candidate.price.toLocaleString()} /><Metric label="등락률" value={candidate.changePercent == null ? '데이터 없음' : formatAppPercent(candidate.changePercent)} /></div>
    {(candidate.target != null || candidate.stop != null) && <div className="grid grid-cols-2 gap-2"><Metric label="목표가" value={candidate.target == null ? '데이터 없음' : candidate.target.toLocaleString()} /><Metric label="손절가" value={candidate.stop == null ? '데이터 없음' : candidate.stop.toLocaleString()} /></div>}
    <Explanation title="판단 이유" rows={candidate.reasons} />
    <Explanation title="위험요인" rows={candidate.risks} />
  </div>;
}

function Explanation({ title, rows }: { title: string; rows: string[] }) {
  return <section className="rounded-2xl border border-card-border bg-background p-3"><h3 className="text-center text-sm font-black">{title}</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-left text-xs font-bold leading-5">{rows.length ? rows.map((row) => <li key={row}>{row}</li>) : <li>확인된 내용이 없습니다.</li>}</ul></section>;
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-secondary/60 p-3 text-center"><p className="text-[10px] font-bold text-muted-foreground">{label}</p><p className="mt-1 text-sm font-black">{value}</p></div>;
}

function SortButton({ label, direction, onClick }: { label: string; direction: SortDirection; onClick: () => void }) {
  const Icon = direction === 'asc' ? ArrowUp : direction === 'desc' ? ArrowDown : ArrowUpDown;
  return <button type="button" onClick={onClick} className="flex items-center justify-center gap-1 rounded-xl border border-card-border bg-background px-2 py-2 text-xs font-black">{label}<Icon className="h-3.5 w-3.5" /></button>;
}

function AssetRow({ row, stock, coinMarket = 'spot', rank, category, onClick }: { row: AnyObj; stock: boolean; coinMarket?: 'spot' | 'futures'; rank?: number; category?: CategoryKey; onClick: () => void }) {
  const symbol = stock ? String(row.ticker) : String(row.symbol);
  const name = stock ? displayStockName(symbol, String(row.name ?? symbol), String(row.market)) : displayCoinName(symbol, row.koreanName, row.englishName);
  const change = finite(row.changePercent ?? row.changePercent24h);
  const price = finite(row.price);
  const currency = stock ? String(row.currency ?? (row.market === 'KR' ? 'KRW' : 'USD')) : coinMarket === 'spot' ? 'KRW' : 'USDT';
  return <button type="button" onClick={onClick} className="flex w-full items-center gap-3 rounded-2xl border border-card-border bg-card p-3 text-left shadow-sm">
    {rank != null && <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-sm font-black text-primary">{rank}</span>}
    <div className="min-w-0 flex-1"><p className="truncate text-sm font-black">{name}</p><p className="mt-0.5 text-[10px] font-bold text-muted-foreground">{symbol}{category === 'ai' ? ` · ${row.categoryLabel ?? row.aiLabel ?? 'AI 후보'}` : ''}</p>{category === 'ai' && Array.isArray(row.reasons) && <p className="mt-1 line-clamp-2 text-[10px] font-bold leading-4 text-foreground/80">{row.reasons.slice(0, 2).join(' · ')}</p>}</div>
    <div className="shrink-0 text-right"><p className="text-xs font-black">{price == null ? '데이터 없음' : formatAppPrice(price, currency)}</p><p className={cn('mt-0.5 text-[10px] font-black', change == null ? 'text-muted-foreground' : change >= 0 ? 'text-positive' : 'text-destructive')}>{change == null ? '—' : formatAppPercent(change)}</p><ChevronRight className="ml-auto mt-1 h-3.5 w-3.5 text-muted-foreground" /></div>
  </button>;
}

function EmptyBox({ children }: { children: React.ReactNode }) {
  return <div className="rounded-3xl border border-card-border bg-card p-5 text-center text-sm font-bold text-muted-foreground">{children}</div>;
}

function dedupe<T>(rows: T[], keyOf: (row: T) => string): T[] {
  const seen = new Set<string>();
  return rows.filter((row) => { const key = keyOf(row); if (seen.has(key)) return false; seen.add(key); return true; });
}

function nameOf(row: AnyObj, stock: boolean): string {
  return stock ? String(row.name ?? row.ticker ?? '') : String(row.koreanName ?? row.englishName ?? row.symbol ?? '');
}

function categoryMetric(category: CategoryKey): string {
  if (category === 'marketCap') return 'marketCap';
  if (category === 'volume') return 'volume';
  if (category === 'tradingValue') return 'tradingValue';
  if (category === 'gainers' || category === 'losers') return 'changePercent';
  return 'score';
}

function metricLabel(category: CategoryKey): string {
  if (category === 'marketCap') return '시가총액';
  if (category === 'volume') return '거래량';
  if (category === 'tradingValue') return '거래대금';
  if (category === 'gainers') return '상승률';
  if (category === 'losers') return '하락률';
  return 'AI점수';
}

function metricValue(row: AnyObj, metric: string): number {
  if (metric === 'volume') return finite(row.volume ?? row.volume24h) ?? -Infinity;
  if (metric === 'tradingValue') return finite(row.tradingValue ?? row.tradingValue24h) ?? -Infinity;
  if (metric === 'changePercent') return finite(row.changePercent ?? row.changePercent24h) ?? -Infinity;
  return finite(row[metric]) ?? -Infinity;
}

function classifyStockAi(row: RecoRow): AiGroup {
  const text = `${row.category} ${row.categoryLabel ?? ''} ${(row.reasons ?? []).join(' ')}`.toLowerCase();
  if (/저평가|per|pbr|가치/.test(text)) return 'undervalued';
  if (/바닥|과매도|낙폭|반등/.test(text)) return 'bottom';
  if (/매집|수급|외국인|기관|obv/.test(text)) return 'accumulation';
  return 'breakout';
}

function buildCoinCandidates(rows: AnyObj[], market: 'spot' | 'futures') {
  const valid = rows.filter((row) => finite(row.price) != null && finite(row.changePercent ?? row.changePercent24h) != null);
  const tradingValues = valid.map((row) => finite(row.tradingValue24h) ?? 0).sort((a, b) => b - a);
  const highValue = tradingValues[Math.min(Math.floor(tradingValues.length * 0.25), Math.max(0, tradingValues.length - 1))] ?? 0;
  return valid.map((row) => {
    const change = finite(row.changePercent ?? row.changePercent24h) ?? 0;
    const value = finite(row.tradingValue24h) ?? 0;
    const price = finite(row.price) ?? 0;
    let aiGroup: AiGroup = 'undervalued';
    let aiLabel = '저평가';
    let opinion = market === 'futures' ? '관망' : '관망';
    const reasons: string[] = [];
    if (change >= 3) { aiGroup = 'breakout'; aiLabel = '추세돌파'; opinion = market === 'futures' ? '롱 후보' : '매수 후보'; reasons.push(`24시간 등락률이 ${change.toFixed(2)}%로 상승 추세입니다.`); }
    else if (change <= -5) { aiGroup = 'bottom'; aiLabel = '바닥권'; opinion = market === 'futures' ? '반등 롱 관찰' : '반등 매수 관찰'; reasons.push(`24시간 ${Math.abs(change).toFixed(2)}% 하락해 과매도 반등 여부를 확인할 구간입니다.`); }
    else if (value >= highValue && Math.abs(change) <= 3) { aiGroup = 'accumulation'; aiLabel = '매집'; opinion = market === 'futures' ? '방향 확인' : '매수 관찰'; reasons.push('등락폭 대비 거래대금이 상위권이라 수급 집중 여부를 확인할 후보입니다.'); }
    else { reasons.push('가격 변동과 거래대금을 함께 비교했을 때 즉시 추격보다 추가 확인이 필요한 후보입니다.'); }
    if (value > 0) reasons.push(`24시간 거래대금 ${value.toLocaleString()} 기준입니다.`);
    const score = Math.max(1, Math.min(99, Math.round(50 + change * 4 + (value >= highValue ? 12 : 0))));
    return { ...row, aiGroup, aiLabel, categoryLabel: aiLabel, opinion, score, reasons, risks: ['급격한 시장 방향 전환과 거래량 감소 시 신호가 무효화될 수 있습니다.'], target: price > 0 ? price * (1 + Math.min(0.08, Math.max(0.02, Math.abs(change) / 100))) : null, stop: price > 0 ? price * 0.97 : null };
  }).sort((a, b) => b.score - a.score);
}
